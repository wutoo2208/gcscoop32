﻿#include "gcs_fsm.h"
#include "gcs_frame.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

static unsigned calls[9], stops;
static int busy;
static void sent(const char *s) { assert(strlen(s)<=GCS_FRAME_MAX); }
static GcsResult action(GcsAction a,const GcsMachine *m,uint8_t first)
{
    if(first) calls[a]++;
    assert(m->batch<2u && m->index<3u);
    return busy ? GCS_BUSY : GCS_OK;
}
static void stop(void) { stops++; }
static GcsOps ops={sent,action,stop};
static void init(GcsMachine *m)
{
    busy=0; memset(calls,0,sizeof(calls)); GcsMachine_Init(m,&ops,1);
    GcsMachine_Start(m);
}
static void qr_wait(GcsMachine *m)
{
    GcsMachine_Poll(m,0); GcsMachine_Poll(m,1); assert(m->state==GCS_Q_WAIT);
}
static void reply_q(GcsMachine *m,const char *code,uint32_t now)
{
    char s[80];
    sprintf(s,"Q|%lu|%s",(unsigned long)m->waiting_sequence,code);
    GcsMachine_Message(m,s,now);
}
static void reply_v(GcsMachine *m,int x,int y,int color,int pos,int path,uint32_t now)
{
    char s[80];
    sprintf(s,"V|%lu|%c|%d|%d|%d|%d|%d",(unsigned long)m->waiting_sequence,
        m->expected_kind,x,y,color,pos,path);
    GcsMachine_Message(m,s,now);
}
static void drive(GcsMachine *m,const char *code)
{
    unsigned i;
    for(i=0;i<1000u && m->state!=GCS_DONE && m->state!=GCS_FAULT;i++) {
        GcsMachine_Poll(m,i*10u);
        if(m->state==GCS_Q_WAIT) reply_q(m,code,i*10u);
        else if(m->state==GCS_V_WAIT) {
            assert(m->color==m->task.colors[m->batch][m->index]);
            assert(m->position==(m->stage==GCS_RAW ? 0 :
                (m->stage==GCS_STORAGE_PUT ? m->task.storage_by_color[m->color] : m->task.rough_by_color[m->color])));
            reply_v(m,320,240,m->color,m->position,m->stage==GCS_RAW ? 2 : 0,i*10u);
        }
    }
    assert(m->state==GCS_DONE);
    assert(calls[GCS_ACT_ROUTE]==8 && calls[GCS_ACT_RAW_PICK]==6);
    assert(calls[GCS_ACT_FIELD_PICK]==6 && calls[GCS_ACT_CARRIER_OUT]==12);
    assert(calls[GCS_ACT_PUT]==9 && calls[GCS_ACT_STACK]==3 && calls[GCS_ACT_OBSERVE]==24);
    for(i=1;i<=3u;i++) assert(!m->slots[i] && !m->rough[i] && m->layers[i]==2u);
    assert(!m->held_color);
    for(i=0;i<3u;i++) assert(m->storage[m->task.storage_by_color[m->task.colors[0][i]]]==m->task.colors[0][i]);
}
static void vision_wait(GcsMachine *m)
{
    unsigned i;
    init(m); qr_wait(m); reply_q(m,"452+321+254+312",2);
    for(i=3;i<20 && m->state!=GCS_V_WAIT;i++) GcsMachine_Poll(m,i);
    assert(m->state==GCS_V_WAIT && m->color==4 && m->position==0);
}
static void feed(GcsReceiver *r,const char *s,uint32_t now)
{
    GcsFrame_Byte(r,255,now);
    while(*s) GcsFrame_Byte(r,(uint8_t)*s++,now);
    GcsFrame_Byte(r,254,now);
}
static void frames(void)
{
    GcsReceiver r; GcsFrame frame;
    const char *samples[]={"987654321","452+321+254+312","04000260325","040002602","123321","00000000E"};
    unsigned i;
    char big[100];
    GcsFrame_Init(&r);
    for(i=0;i<6;i++) feed(&r,samples[i],i);
    for(i=0;i<6;i++) { assert(GcsFrame_Pop(&r,&frame)); assert(!strcmp(frame.text,samples[i])); assert(frame.length==strlen(samples[i])); }
    assert(!GcsFrame_Pop(&r,&frame));
    GcsFrame_Byte(&r,255,10); GcsFrame_Byte(&r,'a',11);
    GcsFrame_Byte(&r,'b',500); GcsFrame_Byte(&r,254,500);
    assert(!GcsFrame_Pop(&r,&frame));
    memset(big,'a',96); big[96]=0; feed(&r,big,600);
    assert(GcsFrame_Pop(&r,&frame) && frame.length==96);
    big[96]='a'; big[97]=0; feed(&r,big,700);
    assert(!GcsFrame_Pop(&r,&frame));
    feed(&r,"OK",800); assert(GcsFrame_Pop(&r,&frame) && !strcmp(frame.text,"OK"));
    GcsFrame_Byte(&r,255,900); GcsFrame_Byte(&r,'x',900); feed(&r,"NEW",900);
    assert(GcsFrame_Pop(&r,&frame) && !strcmp(frame.text,"NEW"));
    GcsFrame_Init(&r);
    for(i=0;i<9;i++) feed(&r,"Q",1000);
    assert(r.dropped==2u);
    for(i=0;i<7;i++) assert(GcsFrame_Pop(&r,&frame));
    assert(!GcsFrame_Pop(&r,&frame));
    GcsFrame_Byte(&r,255,1100); GcsFrame_Byte(&r,0,1100); GcsFrame_Byte(&r,254,1100);
    assert(!GcsFrame_Pop(&r,&frame));
}
static void failures(void)
{
    GcsMachine m; uint32_t previous; unsigned i;
    char s[96];
    vision_wait(&m);
    sprintf(s,"V|%lu|M|320|240|4|0|2",(unsigned long)(m.waiting_sequence+1u));
    GcsMachine_Message(&m,s,30); assert(m.state==GCS_V_WAIT);
    previous=m.waiting_sequence;
    reply_v(&m,320,240,4,0,2,31); assert(m.state==GCS_V_SEND);
    GcsMachine_Message(&m,s,32); assert(m.state==GCS_V_SEND);
    GcsMachine_Poll(&m,33); assert(m.waiting_sequence!=previous);
    reply_v(&m,320,240,4,0,2,34); assert(m.state==GCS_EXECUTE);
    assert(!calls[GCS_ACT_RAW_PICK]);
    GcsMachine_Poll(&m,35); assert(calls[GCS_ACT_RAW_PICK]==1);
    vision_wait(&m); reply_v(&m,640,240,4,0,2,30); assert(m.state==GCS_FAULT);
    vision_wait(&m); reply_v(&m,320,240,5,0,2,30); assert(m.state==GCS_FAULT);
    vision_wait(&m); reply_v(&m,320,240,4,1,2,30); assert(m.state==GCS_FAULT);
    vision_wait(&m); reply_v(&m,320,240,4,0,0,30); assert(m.state==GCS_FAULT);
    vision_wait(&m); reply_v(&m,320,240,4,0,2,30);
    GcsMachine_Poll(&m,31); reply_v(&m,320,240,4,0,3,32); assert(m.state==GCS_FAULT);
    vision_wait(&m); m.dry_run=0;
    reply_v(&m,320,240,4,0,2,30); assert(!strcmp(m.error,"CALIBRATION_REQUIRED"));
    vision_wait(&m); GcsMachine_Poll(&m,20000); assert(m.state==GCS_FAULT);
    init(&m); busy=1; GcsMachine_Poll(&m,0); GcsMachine_Poll(&m,61000);
    assert(!strcmp(m.error,"ACTION_TIMEOUT")); busy=0;
    init(&m); qr_wait(&m); reply_q(&m,"452+331+254+312",2); assert(m.state==GCS_FAULT);
    vision_wait(&m);
    sprintf(s,"E|%lu|NO_TARGET",(unsigned long)m.waiting_sequence);
    GcsMachine_Message(&m,s,30); assert(!strcmp(m.error,"VISION_FAILED"));
    vision_wait(&m); previous=m.sequence; GcsMachine_Message(&m,"STOP",30);
    assert(m.state==GCS_FAULT); GcsMachine_Message(&m,"RESET",31);
    assert(m.state==GCS_IDLE && m.sequence==previous);
    vision_wait(&m); reply_v(&m,350,240,4,0,2,30); assert(m.state==GCS_CORRECT);
    GcsMachine_Poll(&m,31); GcsMachine_Poll(&m,32);
    reply_v(&m,320,240,4,0,2,33); assert(m.state==GCS_V_SEND);
    GcsMachine_Poll(&m,34); reply_v(&m,320,240,4,0,2,35); assert(m.state==GCS_EXECUTE);
    vision_wait(&m);
    for(i=0;i<21u && m.state!=GCS_FAULT;i++) {
        reply_v(&m,350,240,4,0,2,30+i*3u);
        if(m.state==GCS_CORRECT) { GcsMachine_Poll(&m,31+i*3u); GcsMachine_Poll(&m,32+i*3u); }
    }
    assert(!strcmp(m.error,"ALIGN_LIMIT"));
    vision_wait(&m);
    sprintf(s,"V|%lu|M|99999999999999999999|240|4|0|2",(unsigned long)m.waiting_sequence);
    GcsMachine_Message(&m,s,30); assert(m.state==GCS_FAULT);
}
int main(void)
{
    static const char *perms[]={"123","132","213","231","312","321"};
    GcsMachine m;
    GcsTask t;
    GcsCalibration cal={1,314,238,0.5f,0.1f,-0.2f,0.4f};
    float dx,dy;
    unsigned a,b,c,p,r,s,i,total=0;
    char code[16];
    const char *bad[]={"","452+321+254+31","452+321+254+312X",
        "452+321+253+312","445+321+454+312","452+311+254+312","452+321+254+311",
        "752+321+257+312","452-321+254+312"};
    assert(GcsTask_Parse("452+321+254+312",&t));
    assert(t.rough_by_color[4]==3 && t.rough_by_color[5]==2 && t.rough_by_color[2]==1);
    assert(t.storage_by_color[4]==3 && t.storage_by_color[5]==1 && t.storage_by_color[2]==2);
    for(i=0;i<sizeof(bad)/sizeof(bad[0]);i++) assert(!GcsTask_Parse(bad[i],&t));
    frames(); failures();
    GcsAlignment_Offset(&cal,86,22,&dx,&dy);
    assert(fabsf(dx-10.0f)<0.001f && fabsf(dy+8.4f)<0.001f);
    init(&m); drive(&m,"452+321+254+312");
    assert(m.storage[1]==5 && m.storage[2]==2 && m.storage[3]==4);
    for(a=1;a<=6;a++) for(b=1;b<=6;b++) for(c=1;c<=6;c++) {
        unsigned colors[3];
        if(a==b || a==c || b==c) continue;
        colors[0]=a;colors[1]=b;colors[2]=c;
        for(p=0;p<6;p++) for(r=0;r<6;r++) for(s=0;s<6;s++) {
            sprintf(code,"%u%u%u+%s+%u%u%u+%s",a,b,c,perms[r],
                colors[perms[p][0]-'1'],colors[perms[p][1]-'1'],colors[perms[p][2]-'1'],perms[s]);
            init(&m); drive(&m,code); total++;
        }
    }
    printf("PASS: %u complete task combinations; dynamic frames, inventory, stacking, stale replies, faults, timeout, alignment.\n",total);
    return 0;
}
