﻿#include "gcs_fsm.h"
#include <stdio.h>
#include <string.h>
static void send_text(const char *s) { puts(s); fflush(stdout); }
static GcsResult action(GcsAction a,const GcsMachine *m,uint8_t first)
{ (void)a; (void)m; (void)first; return GCS_OK; }
static void stop(void) {}
int main(void)
{
    GcsMachine m;
    GcsOps ops={send_text,action,stop};
    char input[128];
    unsigned count;
    uint32_t now=0;
    GcsMachine_Init(&m,&ops,1);
    GcsMachine_Message(&m,"START",now);
    for(count=0;count<2000u && m.state!=GCS_DONE && m.state!=GCS_FAULT;count++) {
        GcsMachine_Poll(&m,now++);
        if(m.state==GCS_Q_WAIT || m.state==GCS_V_WAIT) {
            size_t n;
            if(!fgets(input,sizeof(input),stdin)) return 2;
            n=strlen(input);
            while(n && (input[n-1]=='\n' || input[n-1]=='\r')) input[--n]=0;
            GcsMachine_Message(&m,input,now++);
        }
    }
    return m.state==GCS_DONE ? 0 : 3;
}
