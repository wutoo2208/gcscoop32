import importlib.util
from pathlib import Path
from types import SimpleNamespace
import subprocess
ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("bridge", str(ROOT / "B01/b01_bridge.py"))
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
service = b.Service(SimpleNamespace(simulate=True, task="452+321+254+312"))
p = subprocess.Popen([str(ROOT / "Tests/.build/replay.exe")],
                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                     text=True, bufsize=1)
transcript = []
try:
    for line in p.stdout:
        text = line.strip()
        transcript.append(text)
        # 每条都通过真实Python FF/FE编码与分帧，再交给服务。
        frames = b.Frames().feed(b.pack(text), now=0)
        reply = service.handle(frames[0])
        if reply:
            parsed = b.Frames().feed(b.pack(reply), now=0)[0]
            p.stdin.write(parsed + "\n")
            p.stdin.flush()
    code = p.wait(timeout=10)
    assert code == 0, p.stderr.read()
    assert transcript.count("DONE") == 1
    items = [x for x in transcript if x.startswith("ITEM_DONE|")]
    assert len(items) == 24
    first_storage = [x for x in items if x.startswith("ITEM_DONE|1|3|")]
    second_rough = [x for x in items if x.startswith("ITEM_DONE|2|1|")]
    second_storage = [x for x in items if x.startswith("ITEM_DONE|2|3|")]
    assert [x.split("|")[-1] for x in first_storage] == ["3", "1", "2"]
    assert [x.split("|")[-1] for x in second_rough] == ["1", "2", "3"]
    assert [x.split("|")[-1] for x in second_storage] == ["2", "1", "3"]
    print("PASS: actual C state machine <-> Python service; QR, 48 fresh vision replies, 24 item actions, final DONE.")
finally:
    if p.poll() is None:
        p.kill()
