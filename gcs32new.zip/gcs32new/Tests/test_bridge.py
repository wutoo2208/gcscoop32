import ast
import importlib.util
import itertools
from pathlib import Path
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("bridge", str(ROOT / "B01" / "b01_bridge.py"))
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)

class BridgeTests(unittest.TestCase):
    def test_python36_syntax(self):
        for name in ("b01_bridge.py", "vision_source.py"):
            ast.parse((ROOT / "B01" / name).read_text(encoding="utf-8-sig"), feature_version=(3, 6))

    def test_frames(self):
        f = bridge.Frames()
        raw = bridge.pack("452+321+254+312") + bridge.pack("04000260325")
        out = []
        for b in raw:
            out += f.feed(bytes([b]), now=0)
        self.assertEqual(out, ["452+321+254+312", "04000260325"])
        self.assertEqual(f.feed(b"\xffhalf", now=0), [])
        self.assertEqual(f.feed(b"tail\xfe", now=1), [])
        self.assertEqual(f.feed(bridge.pack("RECOVER"), now=1), ["RECOVER"])
        self.assertEqual(f.feed(b"\xff" + b"x" * 97 + b"\xfe", now=2), [])
        self.assertEqual(f.feed(bridge.pack("OK"), now=2), ["OK"])

    def test_protocol_and_task(self):
        args = SimpleNamespace(simulate=True, task="452+321+254+312")
        s = bridge.Service(args)
        self.assertIn("SIM_REQUIRES", s.handle("Q|1"))
        s.handle("MODE|LOGIC_ONLY")
        self.assertEqual(s.handle("Q|2"), "Q|2|452+321+254+312")
        self.assertEqual(s.handle("V|3|M|1|0|1|4|0"), "V|3|M|320|240|4|0|2")
        # 第二批黄色在粗加工1、暂存2，绝不按第二批序号重新绑定第二组。
        self.assertEqual(s.handle("V|4|R|2|1|1|2|1"), "V|4|R|320|240|2|1|0")
        self.assertEqual(s.handle("V|5|C|2|3|1|2|2"), "V|5|C|320|240|2|2|0")
        self.assertTrue(s.handle("V|6|R|2|1|1|2|3").startswith("E|6|"))
        self.assertTrue(s.handle("V|7|M|1|0|1|5|0").startswith("E|7|"))
        self.assertTrue(s.handle("V|8|M|1|0|1|0|0").startswith("E|8|"))
        s.handle("MODE|HARDWARE")
        self.assertIn("SIM_REQUIRES", s.handle("V|9|M|1|0|1|4|0"))

    def test_all_task_tables(self):
        count = 0
        for first in itertools.permutations("123456", 3):
            for second in itertools.permutations(first):
                for rough in itertools.permutations("123"):
                    for storage in itertools.permutations("123"):
                        code = "+".join(map("".join, (first, rough, second, storage)))
                        seq, rp, sp = bridge.task_data(code)
                        self.assertEqual(seq, ("".join(first), "".join(second)))
                        self.assertEqual([rp[c] for c in first], list(rough))
                        self.assertEqual([sp[c] for c in first], list(storage))
                        count += 1
        self.assertEqual(count, 25920)

if __name__ == "__main__":
    unittest.main()
