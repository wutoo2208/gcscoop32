﻿/* 仅供ARM语法检查，不能用于实际固件构建或链接。 */
#ifndef GCS_SYNTAX_STDIO_H
#define GCS_SYNTAX_STDIO_H
#include <stddef.h>
#include <stdarg.h>
int sprintf(char *,const char *,...);
int snprintf(char *,size_t,const char *,...);
int vsnprintf(char *,size_t,const char *,va_list);
int printf(const char *,...);
int puts(const char *);
#endif
