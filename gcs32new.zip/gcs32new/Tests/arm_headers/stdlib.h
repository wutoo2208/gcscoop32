﻿#ifndef GCS_SYNTAX_STDLIB_H
#define GCS_SYNTAX_STDLIB_H
#include <stddef.h>
int abs(int);
long strtol(const char *,char **,int);
unsigned long strtoul(const char *,char **,int);
void *malloc(size_t);
void free(void *);
#endif
