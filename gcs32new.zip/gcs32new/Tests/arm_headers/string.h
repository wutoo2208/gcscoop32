﻿#ifndef GCS_SYNTAX_STRING_H
#define GCS_SYNTAX_STRING_H
#include <stddef.h>
void *memset(void *,int,size_t);
void *memcpy(void *,const void *,size_t);
void *memmove(void *,const void *,size_t);
size_t strlen(const char *);
int strcmp(const char *,const char *);
int strncmp(const char *,const char *,size_t);
char *strcpy(char *,const char *);
char *strncpy(char *,const char *,size_t);
char *strcat(char *,const char *);
char *strchr(const char *,int);
int memcmp(const void *,const void *,size_t);
#endif
