"""Finalize the copied project, verify motion integrity, then run tests and package."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import zipfile
ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT.parent / "gcscoop32-main_中文注释重写版.zip"

def decode(raw):
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("gb18030")
    return text.replace("\r\n", "\n").replace("\r", "\n")

def write(rel, text):
    (ROOT / rel).write_text(text, encoding="utf-8-sig" if rel.endswith((".c", ".h")) else "utf-8")

def original(z, rel):
    return z.read("gcscoop32-main/" + rel)

def function(text, name):
    match = re.search(r"\b(?:void|int)\s+" + name + r"\s*\([^;{}]*\)\s*(?://[^\n]*\n\s*)?\{", text)
    if match is None:
        raise ValueError(name)
    pos, depth = match.end(), 1
    while depth:
        if text[pos] == "{": depth += 1
        elif text[pos] == "}": depth -= 1
        pos += 1
    return text[match.start():pos]

with zipfile.ZipFile(ARCHIVE) as z:
    main = decode(original(z, "USER/main.c"))
    # 函数体从原文件原样截取，新增逻辑在前缀和独立文件中。
    tail = main[main.index("// 绿色工位放置"):]
    old_wait = function(tail, "wait_send_shumeipai")
    new_wait = """void wait_send_shumeipai(uint8_t message,uint16_t time)
{
    uint32_t started=GcsClock_Millis();
    while(Serial_GetRxFlag()) {}
    Serial_SendByte(message);
    while((uint32_t)(GcsClock_Millis()-started)<(time ? time : GCS_REPLY_TIMEOUT_MS)) {
        if(Serial_GetRxFlag()) return;
    }
    Serial_RxLength=0; /* 旧接口等待超时；新状态机不使用此函数。 */
}"""
    tail = tail.replace(old_wait, new_wait)
    tail = tail.replace("当前实现只发送一次；time 参数未使用，没有超时、重发或应答内容校验。",
                        "兼容旧接口，新增超时；新流程使用带请求编号的动态帧。")
    tail = tail.replace("// 抓放任务的颜色映射以此分支为准：1 蓝、2 绿、3 红；其他值不执行动作。",
        "// 保留旧机械路径：1原蓝位、2原绿位、3原红位；不是2027颜色编号。")
    tail = tail.replace("// 按抓放任务编号调用对应的取料路径：1 蓝、2 绿、3 红。",
        "// 保留旧取料路径编号；新状态机通过GCS_FIELD_PATH_1/2/3映射调用。")
    prefix = (ROOT / "tools/main_prefix.c.txt").read_text(encoding="utf-8")
    write("USER/main.c", prefix + tail)
    serial = decode(original(z, "SYSTEM/Serial.c"))
    init = function(serial, "Serial_Init")
    init = init.replace('/*开启时钟*/', 'GcsFrame_Init(&receiver);\n\t/*开启时钟*/')
    init = init.replace("GPIO_InitTypeDef GPIO_InitStructure;",
        "GPIO_InitTypeDef GPIO_InitStructure;\n    GPIO_StructInit(&GPIO_InitStructure); /* 新增：串口GPIO所有字段先初始化。 */")
    send_byte = function(serial, "Serial_SendByte")
    header = """#include "stm32f4xx.h"
#include "Serial.h"
#include "gcs_frame.h"
#include "gcs_clock.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
uint8_t Serial_TxPacket[GCS_FRAME_MAX];
uint16_t Serial_TxLength;
uint8_t Serial_RxPacket[GCS_FRAME_MAX+1u];
uint16_t Serial_RxLength;
volatile uint8_t Serial_RxFlag;
int code1[3],code2[3];
static GcsReceiver receiver;
"""
    write("SYSTEM/Serial.c", header + init + "\n" + send_byte + "\n" +
          (ROOT / "SYSTEM/Serial_tail.inc").read_text(encoding="utf-8"))
    exti = decode(original(z, "USER/exti.c")).replace('#include "Serial.h"',
        '#include "Serial.h"\nvolatile uint8_t GcsKeyStartRequested;')
    exti = exti.replace("Serial_SendByte(0x72);", "GcsKeyStartRequested=1; // 新增：中断只提交开始请求，主循环处理。")
    write("USER/exti.c", exti)
    exti_h = decode(original(z, "USER/exti.h")).replace("void Key_EXTI_Init",
        '#include <stdint.h>\nextern volatile uint8_t GcsKeyStartRequested;\n\nvoid Key_EXTI_Init')
    write("USER/exti.h", exti_h)
    pid_h = decode(original(z, "Hardware/pid.h"))
    pid_h = pid_h.replace("uint32_t time,int target);", "uint32_t time,float target); // 声明与原实现保持一致")
    # 新声明末尾注释吞掉原分号的问题通过匹配完整字符串规避。
    write("Hardware/pid.h", pid_h)
    project = decode(original(z, "USER/Template.uvprojx"))
    names = ["gcs_config.h", "gcs_frame.c", "gcs_frame.h", "gcs_task.c", "gcs_task.h",
             "gcs_fsm.c", "gcs_fsm.h", "gcs_calibration.c", "gcs_clock.c", "gcs_clock.h",
             "gcs_port.c", "gcs_port.h"]
    entries = []
    for name in names:
        entries.append("<File><FileName>{}</FileName><FileType>{}</FileType><FilePath>.\\{}</FilePath></File>".format(
            name, 1 if name.endswith(".c") else 5, name))
    group = "<GroupName>USER</GroupName>"
    pos = project.index("<Files>", project.index(group)) + len("<Files>")
    project = project[:pos] + "\n" + "\n".join(entries) + project[pos:]
    project = project.replace("<TargetName>Template</TargetName>", "<TargetName>gcs32new</TargetName>")
    project = project.replace("<OutputName>Template</OutputName>", "<OutputName>gcs32new</OutputName>")
    write("USER/gcs32new.uvprojx", project)
    # AST加载用原Python快照，不修改用户工作目录的Python。
    source = ROOT.parents[2] / "cv2_python/zongchengxu1.0.py"
    (ROOT / "B01/vision_source.py").write_bytes(source.read_bytes())
    motion = ["Hardware/PWM.c","Hardware/servo.c","Hardware/pid.c","can_ZDT/yyb_move.c",
              "can_ZDT/Emm_V5.c","can_ZDT/board.c","can_ZDT/can.c"]
    actions = ["fangzhi_green","fangzhi_red","fangzhi_blue","fangzhi","fangzhi_maduo",
               "na_green","na_blue","na_red","na","yuantai_na","yuantai_na1","yuantai_na2"]
    newmain = (ROOT / "USER/main.c").read_text(encoding="utf-8-sig")
    manifest = {
        "source_archive_sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "preserved_motion_files": {},
        "preserved_action_functions": {},
        "files": {}
    }
    for rel in motion:
        digest = hashlib.sha256(original(z,rel)).hexdigest()
        assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()==digest,rel
        manifest["preserved_motion_files"][rel]=digest
    for name in actions:
        expected = hashlib.sha256(function(main,name).encode("utf-8")).hexdigest()
        assert hashlib.sha256(function(newmain,name).encode("utf-8")).hexdigest()==expected,name
        manifest["preserved_action_functions"][name]=expected
    for path in ROOT.rglob("*"):
        if not path.is_file() or ".build" in path.parts or "__pycache__" in path.parts:
            continue
        rel = path.relative_to(ROOT).as_posix()
        if rel in ("gcs32new_manifest.json", "VALIDATION.txt"):
            continue
        original_name = "gcscoop32-main/" + rel
        status = "new"
        if original_name in z.namelist():
            status = "unchanged" if path.read_bytes()==z.read(original_name) else "modified"
        manifest["files"][rel] = {"status":status, "sha256":hashlib.sha256(path.read_bytes()).hexdigest()}
    write("gcs32new_manifest.json", json.dumps(manifest,ensure_ascii=False,indent=2))

subprocess.run([sys.executable,str(ROOT / "tools/verify.py")],check=True)
# 验证完成后再刷新全部交付文件哈希；清单不记录自身哈希。
manifest["files"] = {}
with zipfile.ZipFile(ARCHIVE) as z:
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file() or any(part in path.parts for part in (".build", "__pycache__")):
            continue
        rel = path.relative_to(ROOT).as_posix()
        if rel == "gcs32new_manifest.json":
            continue
        original_name = "gcscoop32-main/" + rel
        raw = path.read_bytes()
        status = "new"
        if original_name in z.namelist():
            status = "unchanged" if raw == z.read(original_name) else "modified"
        manifest["files"][rel] = {"status":status, "sha256":hashlib.sha256(raw).hexdigest()}
write("gcs32new_manifest.json", json.dumps(manifest,ensure_ascii=False,indent=2))
destination = ROOT.parent / "gcs32new.zip"
if destination.exists():
    raise FileExistsError(destination)
with zipfile.ZipFile(destination,"w",zipfile.ZIP_DEFLATED) as out:
    for path in sorted(ROOT.rglob("*")):
        if path.is_file() and not any(p in path.parts for p in (".build","__pycache__")):
            out.write(path, "gcs32new/" + path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(destination) as out:
    assert out.testzip() is None
print("CREATED",destination,"bytes",destination.stat().st_size)
