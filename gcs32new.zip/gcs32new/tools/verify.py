"""Repeatable host tests; no flashing or hardware access. Run from any directory."""
import ast
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "Tests" / ".build"
BUILD.mkdir(exist_ok=True)
results = []

def run(args, env=None):
    print("RUN:", " ".join(map(str, args)), flush=True)
    p = subprocess.run(list(map(str, args)), cwd=str(BUILD), env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = p.stdout.decode("utf-8", errors="replace")
    print(output, flush=True)
    if p.returncode:
        raise RuntimeError("exit {}: {}".format(p.returncode, args[0]))
    results.append(output.strip())
    return output

for name in ("B01/b01_bridge.py", "B01/vision_source.py"):
    ast.parse((ROOT / name).read_text(encoding="utf-8-sig"), feature_version=(3, 6))
results.append("Python 3.6 syntax: PASS")

# MSVC仅编译可移植核心及测试；不声称得到STM32固件。
vc_roots = sorted(Path("D:/vs2022/VC/Tools/MSVC").glob("*"))
sdk_roots = sorted(Path("C:/Program Files (x86)/Windows Kits/10/Include").glob("10.*"))
if not vc_roots or not sdk_roots:
    raise RuntimeError("Set the local C compiler and Windows SDK paths in tools/verify.py")
vc = vc_roots[-1]
sdk = sdk_roots[-1]
compiler = vc / "bin/Hostx64/x64/cl.exe"
env = os.environ.copy()
env["INCLUDE"] = ";".join(map(str, (vc / "include", sdk / "ucrt", sdk / "shared", sdk / "um")))
libroot = sdk.parent.parent / "Lib" / sdk.name
env["LIB"] = ";".join(map(str, (vc / "lib/x64", libroot / "ucrt/x64", libroot / "um/x64")))
env["PATH"] = str(compiler.parent) + os.pathsep + env.get("PATH", "")
sources = [ROOT / "Tests/test_core.c"] + [ROOT / "USER" / n for n in
           ("gcs_task.c", "gcs_frame.c", "gcs_fsm.c", "gcs_calibration.c")]
run([compiler, "/nologo", "/TC", "/std:c11", "/utf-8", "/W4",
     "/D_CRT_SECURE_NO_WARNINGS", "/I" + str(ROOT / "USER"),
     "/Fe:" + str(BUILD / "test_core.exe")] + sources, env=env)
run([BUILD / "test_core.exe"])
run([sys.executable, ROOT / "Tests/test_bridge.py"])

# 配套Python模拟服务与实际C状态机交互，不使用串口硬件。
replay_sources = [ROOT / "Tests/replay.c"] + sources[1:]
run([compiler, "/nologo", "/TC", "/std:c11", "/utf-8", "/W4",
     "/D_CRT_SECURE_NO_WARNINGS", "/I" + str(ROOT / "USER"),
     "/Fe:" + str(BUILD / "replay.exe")] + replay_sources, env=env)
run([sys.executable, ROOT / "Tests/test_end_to_end.py"])

# 源码完整性：使用生成时记录的原机械动作函数体哈希。
import hashlib
manifest = json.loads((ROOT / "gcs32new_manifest.json").read_text(encoding="utf-8"))
for rel, expected in manifest["preserved_motion_files"].items():
    assert hashlib.sha256((ROOT / rel).read_bytes()).hexdigest() == expected, rel

def function_text(text, name):
    import re
    match = re.search(r"\b(?:void|int)\s+" + name + r"\s*\([^;{}]*\)\s*(?://[^\n]*\n\s*)?\{", text)
    if not match:
        raise AssertionError("missing " + name)
    pos = match.end()
    depth = 1
    while depth:
        if text[pos] == "{": depth += 1
        elif text[pos] == "}": depth -= 1
        pos += 1
    return text[match.start():pos]
main = (ROOT / "USER/main.c").read_text(encoding="utf-8-sig")
for name, expected in manifest["preserved_action_functions"].items():
    assert hashlib.sha256(function_text(main, name).encode("utf-8")).hexdigest() == expected, name
results.append("Original motion files and arm action function bodies: byte/hash comparison PASS")
project = ET.parse(ROOT / "USER/gcs32new.uvprojx")
for node in project.findall(".//FilePath"):
    target = ROOT / "USER" / node.text.replace("\\", "/")
    assert target.resolve().is_file(), str(target)
results.append("Keil project XML and all referenced source paths: PASS")

clang = shutil.which("clang") or "E:/toolbox/sldrt/clang/win64/clang.exe"
if Path(clang).is_file():
    paths = ["CORE", "SYSTEM/delay", "SYSTEM/sys", "SYSTEM/usart", "USER",
             "FWLIB/inc", "can_ZDT", "Hardware", "ckp", "SYSTEM", "imu", "LED", "OLED", "lanya"]
    cmd = [clang, "--target=arm-none-eabi", "-mcpu=cortex-m4", "-mthumb",
           "-mfpu=none", "-mfloat-abi=soft", "-std=c99", "-fsyntax-only",
           "-DSTM32F40_41xxx", "-DUSE_STDPERIPH_DRIVER",
           "-Wno-unknown-attributes", "-Wno-ignored-attributes",
           "-I" + str(ROOT / "Tests/arm_headers")]
    cmd += ["-I" + str(ROOT / p) for p in paths]
    arm_sources = [ROOT / "USER" / n for n in
                   ("main.c", "exti.c", "gcs_task.c", "gcs_frame.c", "gcs_fsm.c",
                    "gcs_calibration.c", "gcs_clock.c", "gcs_port.c")]
    arm_sources += [ROOT / "SYSTEM/Serial.c", ROOT / "Hardware/pid.c"]
    for dry in (1, 0):
        run(cmd + ["-DGCS_DRY_RUN=" + str(dry)] + arm_sources)
    results.append("ARM-target syntax only, both DRY_RUN variants: PASS (soft-float syntax check to bypass old CMSIS GCC vfpcc clobber; project FPU settings unchanged; not MDK link)")
else:
    results.append("ARM syntax check unavailable: no clang")
report = "\n\n".join(results) + "\n\nNOT TESTED: Keil ARM link, firmware flashing, cameras, serial hardware, motor/arm motion, field calibration.\n"
(ROOT / "VALIDATION.txt").write_text(report, encoding="utf-8")
print("PASS. Report:", ROOT / "VALIDATION.txt")
