﻿#ifndef __SERIAL_H
#define __SERIAL_H
#include <stdint.h>
#include "gcs_config.h"
extern uint8_t Serial_TxPacket[GCS_FRAME_MAX];
extern uint16_t Serial_TxLength;
extern uint8_t Serial_RxPacket[GCS_FRAME_MAX+1u];
extern uint16_t Serial_RxLength;
extern volatile uint8_t Serial_RxFlag;
extern int code1[3],code2[3]; /* 保留旧接口，新的任务数据见GcsTask。 */
void Serial_Init(void);
void Serial_SendByte(uint8_t byte);
void Serial_SendArray(uint8_t *array,uint16_t length);
void Serial_SendString(char *text);
void Serial_SendNumber(uint32_t number,uint8_t length);
void Serial_Printf(char *format,...);
void Serial_SendPacket(void); /* 使用Serial_TxLength，不再固定7/9/17字节。 */
uint8_t Serial_SendFrame(const char *text,uint16_t length);
void Serial_SendText(const char *text);
uint8_t Serial_ReadFrame(char *out,uint16_t *length);
uint8_t Serial_GetRxFlag(void);
void set_Rxstate(uint8_t i); /* 兼容旧接口：调用即清理接收状态。 */
#endif
