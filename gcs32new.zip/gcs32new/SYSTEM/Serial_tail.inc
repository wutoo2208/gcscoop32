void Serial_SendArray(uint8_t *array,uint16_t length)
{
    uint16_t i;
    for(i=0;i<length;i++) Serial_SendByte(array[i]);
}
void Serial_SendString(char *text)
{
    while(*text) Serial_SendByte((uint8_t)*text++);
}
void Serial_SendNumber(uint32_t number,uint8_t length)
{
    char s[16];
    if(length>10u) length=10u;
    sprintf(s,"%0*lu",(int)length,(unsigned long)number);
    Serial_SendString(s);
}
void Serial_Printf(char *format,...)
{
    char s[GCS_FRAME_MAX+1u];
    va_list ap;
    va_start(ap,format);
    vsnprintf(s,sizeof(s),format,ap);
    va_end(ap);
    Serial_SendString(s);
}
uint8_t Serial_SendFrame(const char *text,uint16_t length)
{
    uint16_t i;
    if(!text || length==0u || length>GCS_FRAME_MAX) return 0;
    for(i=0;i<length;i++) if((uint8_t)text[i]<0x20u || (uint8_t)text[i]>0x7Eu) return 0;
    Serial_SendByte(0xFFu);
    for(i=0;i<length;i++) Serial_SendByte((uint8_t)text[i]);
    Serial_SendByte(0xFEu);
    return 1;
}
void Serial_SendText(const char *text)
{
    if(text) (void)Serial_SendFrame(text,(uint16_t)strlen(text));
}
void Serial_SendPacket(void)
{
    (void)Serial_SendFrame((const char *)Serial_TxPacket,Serial_TxLength);
}
uint8_t Serial_ReadFrame(char *out,uint16_t *length)
{
    GcsFrame frame;
    uint32_t mask=__get_PRIMASK();
    int ok;
    __disable_irq();
    ok=GcsFrame_Pop(&receiver,&frame);
    Serial_RxFlag=(uint8_t)(receiver.head!=receiver.tail);
    __set_PRIMASK(mask);
    if(!ok) return 0;
    memcpy(out,frame.text,(size_t)frame.length+1u);
    *length=frame.length;
    return 1;
}
uint8_t Serial_GetRxFlag(void)
{
    return Serial_ReadFrame((char *)Serial_RxPacket,&Serial_RxLength);
}
void set_Rxstate(uint8_t i)
{
    uint32_t mask=__get_PRIMASK();
    (void)i;
    __disable_irq();
    GcsFrame_Init(&receiver); Serial_RxFlag=0;
    __set_PRIMASK(mask);
}
void USART1_IRQHandler(void)
{
    uint32_t status=USART1->SR;
    if(status & (USART_SR_RXNE | USART_SR_ORE | USART_SR_FE | USART_SR_NE | USART_SR_PE)) {
        uint8_t byte=(uint8_t)USART1->DR; /* 读SR再读DR清除接收/错误标志。 */
        if(status & (USART_SR_ORE | USART_SR_FE | USART_SR_NE | USART_SR_PE)) {
            receiver.receiving=0; receiver.used=0; receiver.malformed++;
        } else {
            GcsFrame_Byte(&receiver,byte,GcsClock_Millis());
            Serial_RxFlag=(uint8_t)(receiver.head!=receiver.tail);
        }
    }
}
