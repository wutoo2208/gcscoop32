﻿#include "stm32f4xx.h"
#include "Serial.h"
#include "gcs_frame.h"
#include "gcs_clock.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
uint8_t Serial_TxPacket[GCS_FRAME_MAX];
uint16_t Serial_TxLength;
uint8_t Serial_RxPacket[GCS_FRAME_MAX+1u];
uint16_t Serial_RxLength;
volatile uint8_t Serial_RxFlag;
int code1[3],code2[3];
static GcsReceiver receiver;
void Serial_Init(void)
{
	GcsFrame_Init(&receiver);
	/*开启时钟*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);	//开启USART1的时钟
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);	//开启GPIOA的时钟（对于F407，GPIO使用AHB1时钟）

	/*GPIO初始化*/
	GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_StructInit(&GPIO_InitStructure); /* 新增：串口GPIO所有字段先初始化。 */

	/* 配置PA9为USART1的TX (复用推挽输出) */
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);  // 将PA9配置为USART1的复用功能
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;                 // 选择PA9引脚
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;              // 设置为复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;         // 速度选择50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;            // 推挽输出
	GPIO_Init(GPIOA, &GPIO_InitStructure);                    // 初始化PA9

	/* 配置PA10为USART1的RX (上拉输入) */
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);  // 将PA10配置为USART1的复用功能
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;                // 选择PA10引脚
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;              // 设置为复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;         // 速度选择50MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;            // 推挽输出（对于输入引脚，此设置不会生效，但可以保持一致）
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;              // 上拉输入
	GPIO_Init(GPIOA, &GPIO_InitStructure);                    // 初始化PA10
	
	/*USART初始化*/
	USART_InitTypeDef USART_InitStructure;					//定义结构体变量
	USART_InitStructure.USART_BaudRate = 9600;				//波特率
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;	//硬件流控制，不需要
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;	//模式，发送模式和接收模式均选择
	USART_InitStructure.USART_Parity = USART_Parity_No;		//奇偶校验，不需要
	USART_InitStructure.USART_StopBits = USART_StopBits_1;	//停止位，选择1位
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;		//字长，选择8位
	USART_Init(USART1, &USART_InitStructure);				//将结构体变量交给USART_Init，配置USART1
	
	/*中断输出配置*/
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);			//开启串口接收数据的中断
	
	/*NVIC中断分组*/
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);			//配置NVIC为分组2
	
	/*NVIC配置*/
	NVIC_InitTypeDef NVIC_InitStructure;					//定义结构体变量
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;		//选择配置NVIC的USART1线
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//指定NVIC线路使能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;		//指定NVIC线路的抢占优先级为0
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;		//指定NVIC线路的响应优先级为0
	NVIC_Init(&NVIC_InitStructure);							//将结构体变量交给NVIC_Init，配置NVIC外设
	
	/*USART使能*/
	USART_Cmd(USART1, ENABLE);								//使能USART1，串口开始运行
}
void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);		//将字节数据写入数据寄存器，写入后USART自动生成时序波形
	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//等待发送完成
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}
void Serial_SendArray(uint8_t *array,uint16_t length)
{
    uint16_t i;
    for(i=0;i<length;i++) Serial_SendByte(array[i]);
}
void Serial_SendString(char *text)
{
    while(*text) Serial_SendByte((uint8_t)*text++);
}
void Serial_SendNumber(uint32_t number,uint8_t length)
{
    char s[16];
    if(length>10u) length=10u;
    sprintf(s,"%0*lu",(int)length,(unsigned long)number);
    Serial_SendString(s);
}
void Serial_Printf(char *format,...)
{
    char s[GCS_FRAME_MAX+1u];
    va_list ap;
    va_start(ap,format);
    vsnprintf(s,sizeof(s),format,ap);
    va_end(ap);
    Serial_SendString(s);
}
uint8_t Serial_SendFrame(const char *text,uint16_t length)
{
    uint16_t i;
    if(!text || length==0u || length>GCS_FRAME_MAX) return 0;
    for(i=0;i<length;i++) if((uint8_t)text[i]<0x20u || (uint8_t)text[i]>0x7Eu) return 0;
    Serial_SendByte(0xFFu);
    for(i=0;i<length;i++) Serial_SendByte((uint8_t)text[i]);
    Serial_SendByte(0xFEu);
    return 1;
}
void Serial_SendText(const char *text)
{
    if(text) (void)Serial_SendFrame(text,(uint16_t)strlen(text));
}
void Serial_SendPacket(void)
{
    (void)Serial_SendFrame((const char *)Serial_TxPacket,Serial_TxLength);
}
uint8_t Serial_ReadFrame(char *out,uint16_t *length)
{
    GcsFrame frame;
    uint32_t mask=__get_PRIMASK();
    int ok;
    __disable_irq();
    ok=GcsFrame_Pop(&receiver,&frame);
    Serial_RxFlag=(uint8_t)(receiver.head!=receiver.tail);
    __set_PRIMASK(mask);
    if(!ok) return 0;
    memcpy(out,frame.text,(size_t)frame.length+1u);
    *length=frame.length;
    return 1;
}
uint8_t Serial_GetRxFlag(void)
{
    return Serial_ReadFrame((char *)Serial_RxPacket,&Serial_RxLength);
}
void set_Rxstate(uint8_t i)
{
    uint32_t mask=__get_PRIMASK();
    (void)i;
    __disable_irq();
    GcsFrame_Init(&receiver); Serial_RxFlag=0;
    __set_PRIMASK(mask);
}
void USART1_IRQHandler(void)
{
    uint32_t status=USART1->SR;
    if(status & (USART_SR_RXNE | USART_SR_ORE | USART_SR_FE | USART_SR_NE | USART_SR_PE)) {
        uint8_t byte=(uint8_t)USART1->DR; /* 读SR再读DR清除接收/错误标志。 */
        if(status & (USART_SR_ORE | USART_SR_FE | USART_SR_NE | USART_SR_PE)) {
            receiver.receiving=0; receiver.used=0; receiver.malformed++;
        } else {
            GcsFrame_Byte(&receiver,byte,GcsClock_Millis());
            Serial_RxFlag=(uint8_t)(receiver.head!=receiver.tail);
        }
    }
}
