# -*- coding: utf-8 -*-
"""gcs32new配套通信适配器，Python3.6+。不导入原综合程序的串口或任务状态机。"""
import argparse
import ast
import re
import time
from pathlib import Path
from collections import deque

MAX_PAYLOAD = 96

def pack(text):
    data = text.encode("ascii")
    if not 0 < len(data) <= MAX_PAYLOAD or any(b < 32 or b > 126 for b in data):
        raise ValueError("invalid ASCII payload")
    return b"\xff" + data + b"\xfe"

class Frames:
    def __init__(self):
        self.buf = None
        self.last = 0.0

    def feed(self, data, now=None):
        now = time.monotonic() if now is None else now
        out = []
        if self.buf is not None and now - self.last > 0.25:
            self.buf = None
        for b in data:
            self.last = now
            if b == 255:
                self.buf = bytearray()
            elif self.buf is not None:
                if b == 254:
                    if self.buf:
                        out.append(self.buf.decode("ascii"))
                    self.buf = None
                elif b < 32 or b > 126 or len(self.buf) >= MAX_PAYLOAD:
                    self.buf = None
                else:
                    self.buf.append(b)
        return out

def task_data(code):
    if not re.fullmatch(r"[1-6]{3}\+[1-3]{3}\+[1-6]{3}\+[1-3]{3}", code):
        raise ValueError("invalid task format")
    first, rough, second, storage = code.split("+")
    if len(set(first)) != 3 or set(first) != set(second) or len(set(second)) != 3:
        raise ValueError("batch colors must be the same three distinct colors")
    if set(rough) != set("123") or set(storage) != set("123"):
        raise ValueError("positions must be permutations of 123")
    return (first, second), dict(zip(first, rough)), dict(zip(first, storage))

def load_vision(source, cv2, np, thresholds=None):
    tree = ast.parse(Path(source).read_text(encoding="utf-8-sig"))
    assignments = {"COLOR_NAMES", "COLOR_CODES", "COLOR_HSV_RANGES",
                   "COLOR_MORPHOLOGY", "RING_MIN_AREA"}
    functions = {"_make_color_masks", "classify_material_color", "_ring_centers"}
    tree.body = [n for n in tree.body
                 if (isinstance(n, ast.FunctionDef) and n.name in functions)
                 or (isinstance(n, ast.Assign) and any(
                     isinstance(t, ast.Name) and t.id in assignments for t in n.targets))]
    env = {"cv2": cv2, "np": np}
    exec(compile(tree, str(source), "exec"), env)
    if thresholds:
        # 只读取阈值赋值，不执行用户阈值文件内的其他代码。
        for node in ast.parse(Path(thresholds).read_text(encoding="utf-8-sig")).body:
            if isinstance(node, ast.Assign) and any(
                    isinstance(t, ast.Name) and t.id == "COLOR_HSV_RANGES" for t in node.targets):
                env["COLOR_HSV_RANGES"] = ast.literal_eval(node.value)
                break
        else:
            raise ValueError("COLOR_HSV_RANGES missing")
    return env

class CameraVision:
    def __init__(self, args):
        import cv2
        import numpy as np
        self.cv, self.np, self.args = cv2, np, args
        self.env = load_vision(args.source, cv2, np, args.thresholds)
        self.cap = None
        self.device = None

    def camera(self, device):
        if self.device != device:
            if self.cap is not None:
                self.cap.release()
            self.cap = self.cv.VideoCapture(device, self.cv.CAP_V4L2)
            self.device = device
            self.cap.set(self.cv.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(self.cv.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(self.cv.CAP_PROP_BUFFERSIZE, 1)
        if not self.cap.isOpened():
            raise RuntimeError("CAMERA_OPEN")
        # 新请求丢弃少量旧缓冲，再采集确认；驱动是否支持缓冲控制需实测。
        for unused in range(3):
            self.cap.grab()
        return self.cap

    def frame(self, cap):
        ok, image = cap.read()
        if not ok:
            raise RuntimeError("CAMERA_READ")
        if image.shape[:2] != (480, 640):
            raise RuntimeError("FRAME_SIZE")
        return image

    def qr(self):
        from pyzbar.pyzbar import decode
        cap = self.camera(self.args.qr_camera)
        end = time.monotonic() + 8.0
        last, count = None, 0
        while time.monotonic() < end:
            image = self.frame(cap)
            current = None
            for item in decode(self.cv.cvtColor(image, self.cv.COLOR_BGR2GRAY)):
                try:
                    code = item.data.decode("ascii")
                    task_data(code)
                    current = code
                    break
                except (ValueError, UnicodeError):
                    continue
            count = count + 1 if current is not None and current == last else (1 if current else 0)
            last = current
            self.show(image)
            if count >= 3:
                return current
        raise RuntimeError("QR_TIMEOUT")

    def material(self, image, target, raw):
        cv, np = self.cv, self.np
        gray = cv.GaussianBlur(cv.cvtColor(image, cv.COLOR_BGR2GRAY), (9, 9), 2)
        circles = cv.HoughCircles(gray, cv.HOUGH_GRADIENT, dp=1, minDist=25,
                                  param1=45, param2=24, minRadius=18, maxRadius=60)
        if circles is None:
            return None
        hsv = cv.cvtColor(image, cv.COLOR_BGR2HSV)
        choices = []
        for x, y, radius in np.round(circles[0]).astype(int):
            if not (0 <= x < 640 and 0 <= y < 480):
                continue
            mask = np.zeros(gray.shape, np.uint8)
            cv.circle(mask, (x, y), max(1, int(radius * 0.95)), 255, -1)
            color, unused = self.env["classify_material_color"](
                hsv, mask, max(self.env["RING_MIN_AREA"], int(np.pi * radius * radius * 0.08)))
            if color != target:
                continue
            zone = 0 if x < self.args.pick_splits[0] else (1 if x < self.args.pick_splits[1] else 2)
            path = self.args.pick_paths[zone] if raw else 0
            if raw and path == 0:
                raise RuntimeError("PICK_PATH_CONFIG")
            choices.append(((x - 320) ** 2 + (y - 240) ** 2, int(x), int(y), path))
        if not choices:
            return None
        unused, x, y, path = min(choices)
        return x, y, path

    def locate(self, kind, color, position):
        cap = self.camera(self.args.material_camera)
        end = time.monotonic() + 8.0
        history = deque(maxlen=6)
        while time.monotonic() < end:
            image = self.frame(cap)
            if kind == "R":
                centers = self.env["_ring_centers"](image)
                # 沿用固定排列推定工位，不宣称实现OCR。必须实测相机朝向。
                labels = dict(zip(self.args.ring_labels, centers)) if len(centers) == 3 else {}
                item = (labels[position][0], labels[position][1], 0) if position in labels else None
            else:
                # C用于粗加工取回或同色码垛，必须实际匹配目标颜色。
                item = self.material(image, color, kind == "M")
            if item is None:
                history.clear()
            else:
                history.append(item)
                self.cv.drawMarker(image, item[:2], (0, 255, 255), self.cv.MARKER_CROSS, 18, 2)
                if len(history) == 6 and all(
                        (p[0] - item[0]) ** 2 + (p[1] - item[1]) ** 2 <= 25
                        and p[2] == item[2] for p in history):
                    return (int(round(sum(p[0] for p in history) / 6.0)),
                            int(round(sum(p[1] for p in history) / 6.0)), item[2])
            self.show(image)
        raise RuntimeError("TARGET_TIMEOUT")

    def show(self, image):
        if self.args.preview:
            self.cv.imshow("gcs32new vision", image)
            if self.cv.waitKey(1) & 255 == ord("q"):
                raise KeyboardInterrupt()

    def close(self):
        if self.cap is not None:
            self.cap.release()
        self.cv.destroyAllWindows()

class Service:
    def __init__(self, args, vision=None):
        self.args, self.vision = args, vision
        self.mode = "UNKNOWN"
        self.task = None

    def handle(self, text):
        if text.startswith("MODE|"):
            self.mode = text.split("|", 1)[1]
            return None
        p = text.split("|")
        if not p or p[0] not in ("Q", "V"):
            return None
        if len(p) < 2 or not p[1].isdigit() or not 0 < int(p[1]) <= 0xffffffff:
            return None
        ident = p[1]
        try:
            if self.args.simulate and self.mode != "LOGIC_ONLY":
                raise ValueError("SIM_REQUIRES_LOGIC_ONLY")
            if p[0] == "Q" and len(p) == 2:
                code = self.args.task if self.args.simulate else self.vision.qr()
                self.task = task_data(code)
                return "Q|{}|{}".format(ident, code)
            if p[0] == "V" and len(p) == 8:
                unused, unused_id, kind, batch, stage, index, color, position = p
                if kind not in ("M", "R", "C") or not all(v.isdigit() for v in (batch, stage, index, color, position)):
                    raise ValueError("REQUEST")
                b, s, i = int(batch), int(stage), int(index)
                if b not in (1, 2) or s not in (0, 1, 2, 3) or i not in (1, 2, 3) or self.task is None:
                    raise ValueError("CONTEXT")
                sequences, rough, storage = self.task
                expected_color = sequences[b - 1][i - 1]
                expected_position = "0" if s == 0 else (storage[color] if s == 3 else rough[color])
                expected_kind = "M" if s == 0 else ("C" if s == 2 or (s == 3 and b == 2) else "R")
                if color != expected_color or position != expected_position or kind != expected_kind:
                    raise ValueError("TARGET_CONTEXT")
                if self.args.simulate:
                    x, y, path = 320, 240, (2 if kind == "M" else 0)
                else:
                    x, y, path = self.vision.locate(kind, color, position)
                return "V|{}|{}|{}|{}|{}|{}|{}".format(ident, kind, x, y, color, position, path)
            raise ValueError("REQUEST")
        except (ValueError, RuntimeError, KeyError) as exc:
            reason = re.sub("[^A-Za-z0-9_]", "_", str(exc))[:32] or "ERROR"
            return "E|{}|{}".format(ident, reason)

def triple(text):
    vals = tuple(int(v) for v in text.split(","))
    if len(vals) != 3 or any(v < 0 or v > 3 for v in vals):
        raise argparse.ArgumentTypeError("need three values in 0..3")
    return vals

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", default="/dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=9600)
    parser.add_argument("--simulate", action="store_true", help="仅响应MODE LOGIC_ONLY，使用模拟坐标")
    parser.add_argument("--task", default="452+321+254+312")
    parser.add_argument("--start", action="store_true")
    parser.add_argument("--reset", action="store_true", help="仅复位任务数据，不执行机构回零")
    parser.add_argument("--source", default=str(Path(__file__).with_name("vision_source.py")))
    parser.add_argument("--thresholds")
    parser.add_argument("--qr-camera", default="/dev/video_xia0")
    parser.add_argument("--material-camera", default="/dev/video_shang0")
    parser.add_argument("--ring-labels", default="3,2,1")
    parser.add_argument("--pick-paths", type=triple, default=(0, 0, 0), help="画面三个区域对应的原抓料路径，须实测")
    parser.add_argument("--pick-splits", default="213,426", help="左右分区边界像素，须实测")
    parser.add_argument("--preview", action="store_true")
    args = parser.parse_args()
    task_data(args.task)
    args.ring_labels = tuple(args.ring_labels.split(","))
    args.pick_splits = tuple(int(v) for v in args.pick_splits.split(","))
    if set(args.ring_labels) != set("123") or len(args.ring_labels) != 3:
        parser.error("--ring-labels must be a permutation of 1,2,3")
    if len(args.pick_splits) != 2 or not 0 < args.pick_splits[0] < args.pick_splits[1] < 640:
        parser.error("invalid --pick-splits")
    import serial
    vision = None if args.simulate else CameraVision(args)
    service = Service(args, vision)
    frames = Frames()
    try:
        with serial.Serial(args.port, args.baud, timeout=0.1, write_timeout=1) as port:
            print("Opened {}; simulation={}".format(args.port, args.simulate), flush=True)
            if args.reset:
                port.write(pack("RESET"))
            if args.start:
                port.write(pack("START"))
            try:
                while True:
                    data = port.read(port.in_waiting or 1)
                    for text in frames.feed(data):
                        print("STM32: " + text, flush=True)
                        reply = service.handle(text)
                        if reply:
                            port.write(pack(reply))
                            print("B01: " + reply, flush=True)
            except KeyboardInterrupt:
                port.write(pack("STOP"))
                print("STOP sent; legacy blocking arm moves are not asynchronously interrupted.", flush=True)
    finally:
        if vision:
            vision.close()

if __name__ == "__main__":
    main()
