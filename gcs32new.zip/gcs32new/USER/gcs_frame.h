﻿#ifndef GCS_FRAME_H
#define GCS_FRAME_H
#include "gcs_config.h"
typedef struct { uint16_t length; char text[GCS_FRAME_MAX + 1u]; } GcsFrame;
typedef struct {
    GcsFrame queue[GCS_FRAME_QUEUE];
    char assembling[GCS_FRAME_MAX + 1u];
    volatile uint8_t head, tail;
    uint16_t used;
    uint8_t receiving;
    uint32_t last_byte_ms;
    volatile uint32_t dropped, malformed;
} GcsReceiver;
void GcsFrame_Init(GcsReceiver *r);
void GcsFrame_Byte(GcsReceiver *r, uint8_t byte, uint32_t now);
int GcsFrame_Pop(GcsReceiver *r, GcsFrame *out);
#endif
