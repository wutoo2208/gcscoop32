﻿#ifndef GCS_CONFIG_H
#define GCS_CONFIG_H
#include <stdint.h>

/* 新增：先演练逻辑；改成0后才允许调用原有运动函数。 */
#ifndef GCS_DRY_RUN
#define GCS_DRY_RUN 1
#endif
#define GCS_FRAME_MAX 96u
#define GCS_FRAME_QUEUE 8u
#define GCS_RX_GAP_MS 250u
#define GCS_REPLY_TIMEOUT_MS 12000u
#define GCS_ACTION_TIMEOUT_MS 60000u
#define GCS_PROCESS_WAIT_MS 0u /* TODO：按实际加工等待要求设置。 */
#define GCS_IMAGE_WIDTH 640u
#define GCS_IMAGE_HEIGHT 480u
#define GCS_ALIGN_TOLERANCE_PX 4.0f
#define GCS_ALIGN_CONFIRMATIONS 2u
#define GCS_MAX_CORRECTIONS 20u
#define GCS_MAX_STEP_MM 10.0f
#define GCS_PLATFORM_SETTLE_MS 400u

/* TODO：不是回零命令。确认机构已回零、原动作可用后才设为1。 */
#define GCS_MECHANISM_READY 0
/* TODO：填场地位置 -> 原fangzhi/na路径编号；原1蓝路径、2绿路径、3红路径。
   它们现在仅是机械路径编号，不再表示2027颜色。0表示未标定。 */
#define GCS_FIELD_PATH_1 0
#define GCS_FIELD_PATH_2 0
#define GCS_FIELD_PATH_3 0

typedef struct {
    uint8_t ready;
    float u0, v0;
    /* 有符号2x2矩阵：像素误差 -> car_move2/car_move1的输入毫米数。
       包含方向、轴交换和比例，不能直接照搬旧经验公式。 */
    float xx, xy, yx, yy;
} GcsCalibration;
extern const GcsCalibration gcs_calibration[4][4];
extern const GcsCalibration gcs_stack_calibration[4];
#endif
