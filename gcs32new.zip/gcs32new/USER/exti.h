﻿#ifndef __EXTI_H
#define __EXTI_H

#include <stdint.h>
extern volatile uint8_t GcsKeyStartRequested;

void Key_EXTI_Init(void);

#endif