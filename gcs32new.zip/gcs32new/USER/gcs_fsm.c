﻿#include "gcs_fsm.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

static int due(uint32_t now, uint32_t end) { return (int32_t)(now-end)>=0; }
static void emit(GcsMachine *m, const char *s) { if(m->ops.send) m->ops.send(s); }
static void state(GcsMachine *m, GcsState s) { m->state=s; m->action_started=0; }
static void fail(GcsMachine *m, const char *why)
{
    char msg[64];
    strncpy(m->error, why, sizeof(m->error)-1u);
    m->error[sizeof(m->error)-1u]=0;
    state(m,GCS_FAULT);
    if(m->ops.stop) m->ops.stop();
    sprintf(msg,"FAULT|%s",m->error); emit(m,msg);
}
void GcsMachine_Init(GcsMachine *m, const GcsOps *ops, uint8_t dry_run)
{
    memset(m,0,sizeof(*m)); m->ops=*ops; m->dry_run=dry_run; m->state=GCS_IDLE;
}
void GcsMachine_Start(GcsMachine *m)
{
    if(m->state!=GCS_IDLE) return;
    m->route=GCS_TO_QR; state(m,GCS_ROUTE);
    emit(m,m->dry_run ? "MODE|LOGIC_ONLY" : "MODE|HARDWARE");
}
static int run_action(GcsMachine *m, GcsAction a, uint32_t now)
{
    GcsResult r;
    char msg[80];
    uint8_t first=(uint8_t)!m->action_started;
    if(first) {
        m->action_started=1; m->action_deadline=now+GCS_ACTION_TIMEOUT_MS;
        sprintf(msg,"ACTION|%u|%u|%u|%u|%u|%u|%u|%u",
            (unsigned)a,(unsigned)(m->batch+1u),(unsigned)m->stage,
            (unsigned)(m->index+1u),(unsigned)m->color,(unsigned)m->position,
            (unsigned)m->slot,(unsigned)m->pick_path);
        emit(m,msg);
    }
    if(!m->ops.action) { fail(m,"NO_ACTION_PORT"); return 0; }
    r=m->ops.action(a,m,first);
    if(r==GCS_FAILED) { fail(m,"ACTION_FAILED"); return 0; }
    if(r==GCS_BUSY) {
        if(due(now,m->action_deadline)) fail(m,"ACTION_TIMEOUT");
        return 0;
    }
    m->action_started=0;
    return 1;
}
static char kind(const GcsMachine *m)
{
    if(m->stage==GCS_RAW) return 'M';
    if(m->stage==GCS_ROUGH_GET || (m->stage==GCS_STORAGE_PUT && m->batch==1u)) return 'C';
    return 'R';
}
static void select_item(GcsMachine *m)
{
    m->color=m->task.colors[m->batch][m->index];
    m->position=m->stage==GCS_RAW ? 0u :
        (m->stage==GCS_STORAGE_PUT ? m->task.storage_by_color[m->color] : m->task.rough_by_color[m->color]);
    m->slot=(uint8_t)(m->index+1u);
    m->pick_path=0; m->aligned=0; m->corrections=0;
}
static void advance(GcsMachine *m, uint32_t now)
{
    char msg[64];
    sprintf(msg,"ITEM_DONE|%u|%u|%u|%u|%u",(unsigned)(m->batch+1u),
        (unsigned)m->stage,(unsigned)(m->index+1u),(unsigned)m->color,(unsigned)m->position);
    emit(m,msg);
    m->index++;
    if(m->index<3u) { state(m,GCS_PREPARE); return; }
    m->index=0;
    if(m->stage==GCS_RAW) {
        m->stage=GCS_ROUGH_PUT; m->route=GCS_TO_ROUGH; state(m,GCS_ROUTE);
    } else if(m->stage==GCS_ROUGH_PUT) {
        m->stage=GCS_ROUGH_GET; m->deadline=now+GCS_PROCESS_WAIT_MS; state(m,GCS_PROCESS_WAIT);
    } else if(m->stage==GCS_ROUGH_GET) {
        m->stage=GCS_STORAGE_PUT; m->route=GCS_TO_STORAGE; state(m,GCS_ROUTE);
    } else if(m->batch==0u) {
        m->batch=1; m->stage=GCS_RAW; m->route=GCS_TO_RAW; state(m,GCS_ROUTE);
    } else {
        m->route=GCS_TO_FINISH; state(m,GCS_ROUTE);
    }
}
static float clamp_step(float x)
{
    if(x>GCS_MAX_STEP_MM) return GCS_MAX_STEP_MM;
    if(x<-GCS_MAX_STEP_MM) return -GCS_MAX_STEP_MM;
    return x;
}
void GcsAlignment_Offset(const GcsCalibration *cal,float ex,float ey,float *dx,float *dy)
{
    *dx=clamp_step(cal->xx*ex+cal->xy*ey);
    *dy=clamp_step(cal->yx*ex+cal->yy*ey);
}
static void accept_vision(GcsMachine *m, uint32_t now)
{
    const GcsCalibration *cal;
    unsigned pose=m->stage==GCS_RAW ? m->pick_path : m->position;
    float ex,ey;
    (void)now;
    cal=(m->stage==GCS_STORAGE_PUT && m->batch==1u) ? &gcs_stack_calibration[pose] : &gcs_calibration[m->stage][pose];
    if(!m->dry_run && !cal->ready) { fail(m,"CALIBRATION_REQUIRED"); return; }
    ex=(float)m->x-cal->u0; ey=(float)m->y-cal->v0;
    if(fabsf(ex)<=GCS_ALIGN_TOLERANCE_PX && fabsf(ey)<=GCS_ALIGN_TOLERANCE_PX) {
        m->aligned++;
        if(m->aligned<GCS_ALIGN_CONFIRMATIONS) { state(m,GCS_V_SEND); return; }
        /* 放置前先从车载槽取出；两种取料路径本身已包含回车载平台松爪。 */
        state(m,(m->stage==GCS_ROUGH_PUT || m->stage==GCS_STORAGE_PUT) ? GCS_TAKE_OUT : GCS_EXECUTE);
        return;
    }
    m->aligned=0;
    if(++m->corrections>GCS_MAX_CORRECTIONS) { fail(m,"ALIGN_LIMIT"); return; }
    GcsAlignment_Offset(cal,ex,ey,&m->move_x,&m->move_y);
    if(!m->dry_run && fabsf(m->move_x)<1.0f && fabsf(m->move_y)<1.0f) {
        fail(m,"ALIGN_STEP_TOO_SMALL"); return;
    }
    state(m,GCS_CORRECT);
}
void GcsMachine_Poll(GcsMachine *m, uint32_t now)
{
    char msg[96];
    GcsAction action;
    switch(m->state) {
    case GCS_IDLE: case GCS_DONE: case GCS_FAULT: break;
    case GCS_ROUTE:
        if(!run_action(m,GCS_ACT_ROUTE,now)) break;
        if(m->route==GCS_TO_FINISH) { state(m,GCS_DONE); emit(m,"DONE"); }
        else state(m,m->route==GCS_TO_QR ? GCS_Q_SEND : GCS_PREPARE);
        break;
    case GCS_Q_SEND:
        m->waiting_sequence=++m->sequence;
        sprintf(msg,"Q|%lu",(unsigned long)m->waiting_sequence);
        m->deadline=now+GCS_REPLY_TIMEOUT_MS; state(m,GCS_Q_WAIT); emit(m,msg);
        break;
    case GCS_Q_WAIT: case GCS_V_WAIT:
        if(due(now,m->deadline)) fail(m,"REPLY_TIMEOUT");
        break;
    case GCS_PREPARE:
        if(!m->action_started) select_item(m);
        if(run_action(m,GCS_ACT_OBSERVE,now)) state(m,GCS_V_SEND);
        break;
    case GCS_V_SEND:
        m->waiting_sequence=++m->sequence; m->expected_kind=kind(m);
        sprintf(msg,"V|%lu|%c|%u|%u|%u|%u|%u",(unsigned long)m->waiting_sequence,m->expected_kind,
            (unsigned)(m->batch+1u),(unsigned)m->stage,(unsigned)(m->index+1u),
            (unsigned)m->color,(unsigned)m->position);
        m->deadline=now+GCS_REPLY_TIMEOUT_MS; state(m,GCS_V_WAIT); emit(m,msg);
        break;
    case GCS_CORRECT:
        if(run_action(m,GCS_ACT_CORRECT,now)) state(m,GCS_V_SEND);
        break;
    case GCS_TAKE_OUT:
        if(m->slots[m->slot]!=m->color) { fail(m,"CARRIER_COLOR"); break; }
        if(run_action(m,GCS_ACT_CARRIER_OUT,now)) {
            m->slots[m->slot]=0; m->held_color=m->color; state(m,GCS_EXECUTE);
        }
        break;
    case GCS_EXECUTE:
        if(m->stage==GCS_RAW) {
            if(m->slots[m->slot]) { fail(m,"CARRIER_OCCUPIED"); break; }
            action=GCS_ACT_RAW_PICK;
        } else if(m->stage==GCS_ROUGH_GET) {
            if(m->rough[m->position]!=m->color || m->slots[m->slot]) { fail(m,"ROUGH_COLOR"); break; }
            action=GCS_ACT_FIELD_PICK;
        } else {
            if(m->held_color!=m->color) { fail(m,"HELD_COLOR"); break; }
            if(m->stage==GCS_ROUGH_PUT && m->rough[m->position]) { fail(m,"ROUGH_OCCUPIED"); break; }
            if(m->stage==GCS_STORAGE_PUT &&
                ((m->batch==0u && m->layers[m->position]!=0u) ||
                 (m->batch==1u && (m->storage[m->position]!=m->color || m->layers[m->position]!=1u)))) {
                fail(m,"STACK_COLOR"); break;
            }
            action=(m->stage==GCS_STORAGE_PUT && m->batch==1u) ? GCS_ACT_STACK : GCS_ACT_PUT;
        }
        if(!run_action(m,action,now)) break;
        if(m->stage==GCS_RAW) m->slots[m->slot]=m->color;
        else if(m->stage==GCS_ROUGH_GET) { m->rough[m->position]=0; m->slots[m->slot]=m->color; }
        else if(m->stage==GCS_ROUGH_PUT) { m->held_color=0; m->slots[m->slot]=0; m->rough[m->position]=m->color; }
        else { m->held_color=0; m->slots[m->slot]=0; m->storage[m->position]=m->color; m->layers[m->position]++; }
        advance(m,now);
        break;
    case GCS_PROCESS_WAIT:
        if(due(now,m->deadline)) state(m,GCS_PREPARE);
        break;
    default: fail(m,"BAD_STATE"); break;
    }
}
/* 严格分隔字段并限制整数范围，拒绝旧包、超界坐标和错误目标。 */
static int split(char *s, char **p, int max)
{
    int n=0;
    if(!*s) return 0;
    p[n++]=s;
    while(*s) {
        if(*s=='|') {
            *s=0;
            if(!*p[n-1] || n>=max) return 0;
            p[n++]=s+1;
        }
        s++;
    }
    return *p[n-1] ? n : 0;
}
static int number(const char *s, uint32_t max, uint32_t *out)
{
    uint32_t v=0,d;
    if(!*s) return 0;
    while(*s) {
        if(*s<'0' || *s>'9') return 0;
        d=(uint32_t)(*s++-'0');
        if(d>max || v>(max-d)/10u) return 0;
        v=v*10u+d;
    }
    *out=v; return 1;
}
void GcsMachine_Message(GcsMachine *m, const char *text, uint32_t now)
{
    char buf[GCS_FRAME_MAX+1u], *p[10];
    uint32_t id,x,y,c,pos,path;
    GcsTask task;
    int n;
    if(strlen(text)>GCS_FRAME_MAX) return;
    if(!strcmp(text,"START")) { GcsMachine_Start(m); return; }
    if(!strcmp(text,"STOP")) { fail(m,"STOPPED"); return; }
    if(!strcmp(text,"RESET")) {
        if(m->state==GCS_IDLE || m->state==GCS_DONE || m->state==GCS_FAULT) {
            GcsOps ops=m->ops;
            uint8_t dry=m->dry_run;
            uint32_t seq=m->sequence; /* 重置时不复用旧请求编号。 */
            GcsMachine_Init(m,&ops,dry); m->sequence=seq; emit(m,"READY");
        }
        return;
    }
    strcpy(buf,text); n=split(buf,p,10);
    if(n>=2 && number(p[1],0xFFFFFFFFu,&id)) {
        if(id!=m->waiting_sequence || (m->state!=GCS_Q_WAIT && m->state!=GCS_V_WAIT)) return;
        if(due(now,m->deadline)) { fail(m,"LATE_REPLY"); return; }
        if(!strcmp(p[0],"E")) { fail(m,"VISION_FAILED"); return; }
        if(n==3 && !strcmp(p[0],"Q") && m->state==GCS_Q_WAIT) {
            if(!GcsTask_Parse(p[2],&task)) { fail(m,"INVALID_TASK"); return; }
            m->task=task; m->batch=0; m->index=0; m->stage=GCS_RAW;
            m->route=GCS_TO_RAW; state(m,GCS_ROUTE); emit(m,"TASK_OK"); return;
        }
        if(n==8 && !strcmp(p[0],"V") && m->state==GCS_V_WAIT && p[2][0]==m->expected_kind && !p[2][1]) {
            if(!number(p[3],GCS_IMAGE_WIDTH-1u,&x) || !number(p[4],GCS_IMAGE_HEIGHT-1u,&y) ||
               !number(p[5],6u,&c) || !number(p[6],3u,&pos) || !number(p[7],3u,&path) ||
               c!=m->color || pos!=m->position || (m->stage==GCS_RAW ? path==0u : path!=0u)) {
                fail(m,"INVALID_VISION"); return;
            }
            if(m->stage==GCS_RAW && m->pick_path && path!=m->pick_path) { fail(m,"PICK_PATH_CHANGED"); return; }
            m->x=(uint16_t)x; m->y=(uint16_t)y; m->pick_path=(uint8_t)path;
            accept_vision(m,now);
        }
    }
}
