﻿/*
 * gcs32new：通用任务状态机入口。原机械臂动作函数保留在本文件下半部。
 */
#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "board.h"
#include "Emm_V5.h"
#include "uart6_ckp.h"
#include "Serial.h"
#include "yyb_move.h"
#include "imu.h"
#include "PWM.h"
#include "LED.h"
#include "OLED.h"
#include "swith.h"
#include "pid.h"
#include "usart5.h"
#include "wit_c_sdk.h"
#include "exti.h"
#include "gcs_clock.h"
#include "gcs_port.h"
#include <string.h>

/* 下列宏/变量供保留的旧函数引用，新状态机不用旧坐标补偿。 */
#define x_center_red 955
#define y_center_red 519
#define x_center_green 955
#define y_center_green 519
#define x_center_blue 955
#define y_center_blue 519
char tjcstr[100];
int acc[4];
float direct_x=0, direct_y=0, distance_wukuai=150, x_origin=0, y_origin=0;
int task[17], ypcode[6];
float angle=0;
char message[]="Hello, BT - 04 from STM32F407!\r\n";
void transfer_position_wukuai(uint8_t task_choose,float distance,uint8_t color);
void transfer_position_sehuan(uint8_t resolution,uint8_t position);
void fangzhi(uint8_t path);
void fangzhi_maduo(uint8_t path);
void na(uint8_t path);
void yuantai_na(uint8_t path);
void yuantai_na1(uint8_t path);
void yuantai_na2(uint8_t path);
void wait_send_shumeipai(uint8_t message,uint16_t time);
void clear_ckp(void);
void jixie_reset(void);

GcsMachine gcs_machine; /* 可在Keil Watch查看state/stage/task/slots/rough/storage。 */
static void send_message(const char *text) { Serial_SendText(text); }

int main(void)
{
    GcsOps ops={send_message,GcsPort_Action,GcsPort_Stop};
    char frame[GCS_FRAME_MAX+1u], last_task[16]="";
    uint16_t length;
    uint32_t now, last_display=0, last_key=0;
    delay_init(168);
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    OLED_Init();
    Timer6_Init();
    LED_Init();
    uart6_init(9600);
    GcsClock_Init();
    Serial_Init();
    Key_EXTI_Init();
#if !GCS_DRY_RUN
    /* 新增：逻辑模式不初始化会输出电机/舵机信号的运动外设。 */
    board_init();
    PWM_Init();
    uart5_init(9600);
    Swith_Init();
    imu_init();
    PIDInit();
    dianji_move_flag=1;
    TIM_SetCompare1(TIM3,0);
#endif
    clear_ckp();
    GcsMachine_Init(&gcs_machine,&ops,GCS_DRY_RUN);
    Serial_SendText("READY");
    while(1) {
        now=GcsClock_Millis();
        if(GcsKeyStartRequested) {
            GcsKeyStartRequested=0;
            if(last_key==0u || (uint32_t)(now-last_key)>300u) {
                GcsMachine_Start(&gcs_machine);
                last_key=now;
            }
        }
        while(Serial_ReadFrame(frame,&length))
            GcsMachine_Message(&gcs_machine,frame,GcsClock_Millis());
        GcsMachine_Poll(&gcs_machine,GcsClock_Millis());
        if(strcmp(last_task,gcs_machine.task.code)) {
            strcpy(last_task,gcs_machine.task.code);
            sprintf(tjcstr,"t0.txt=\"%s\"",last_task);
            HMISends(tjcstr); HMISendb(0xff);
        }
        if((uint32_t)(now-last_display)>250u) {
            last_display=now;
            OLED_ShowString(1,1,"S:"); OLED_ShowNum(1,3,gcs_machine.state,2);
            OLED_ShowString(1,6,"B:"); OLED_ShowNum(1,8,gcs_machine.batch+1u,1);
            OLED_ShowString(2,1,"P:"); OLED_ShowNum(2,3,gcs_machine.stage,1);
            OLED_ShowString(2,6,"I:"); OLED_ShowNum(2,8,gcs_machine.index+1u,1);
        }
    }
}

// 绿色工位放置：经中间姿态转向 278 度工位，到达预设放置位置后张开夹爪。
void fangzhi_green(void)   //2
{
	move_all(-48.0f,1000,200   ,25,1000,200   ,135,13);
	move_all(-20.0f,1000,200   ,25,1000,200   ,135,13);
	move_all(-20.0f,1000,200   ,25,1000,200   ,278,13);
	move_all(-50.0f,1000,200   ,132,1000,200   ,278,13);
	set_zhuashou_kai();
}

// 红色工位放置：转向 236 度工位，升降轴到达 132 后张开夹爪。
void fangzhi_red(void)   //3
{
	move_all(-48.0f,1000,200   ,25,1000,200   ,135,13);
	move_all(3.0f+1.0f,1000,200   ,25,1000,200   ,236.0f,13);
	move_all(3.0f+1.0f,1000,200   ,132,1000,200   ,236.0f,13);
	
	set_zhuashou_kai();
}
// 蓝色工位放置：使用 317 + 1.4 度的云台标定值，到达放置姿态后张开夹爪。
void fangzhi_blue(void)   //1
{
	move_all(-48.0f,1000,200   ,25,1000,200   ,135,13);
	move_all(3.0f+5.8f,1000,200   ,25,1000,200   ,317.0f+1.4f,13);
	move_all(3.0f+5.8f,1000,200   ,132,1000,200   ,317.0f+1.4f,13);
	set_zhuashou_kai();
}

// 保留旧机械路径：1原蓝位、2原绿位、3原红位；不是2027颜色编号。
void fangzhi(uint8_t task)
{
	if(task == 0x01){
		fangzhi_blue();
	}else if(task == 0x02){
		fangzhi_green();
	}else if(task == 0x03){
		fangzhi_red();
	}
}

// 码垛动作使用升降目标 130 - 70 = 60，区别于普通放置时的 132。
void fangzhi_maduo(uint8_t task)
{
	if(task == 0x03){   //red   3
		move_all(-48.0f,1000,200   ,25,1000,200   ,135,13);
		move_all(3.0f,1000,200   ,25,1000,200   ,236,13);
		move_all(3.0f,1000,200   ,130-70,1000,200   ,236,13);
		set_zhuashou_kai();
	}else if(task == 0x02){   //green   2
		move_all(-48.0f,1000,200   ,25,1000,200   ,135,13);
		move_all(-48.0f,1000,200   ,25,1000,200   ,180,13);
		move_all(-120.0f,1000,200   ,25,1000,200   ,278,13);
		move_all(-50.0f,1000,200   ,130-70,1000,200   ,278,13);
		set_zhuashou_kai();
	}else if(task == 0x01){   //blue   1
		move_all(-48.0f,1000,200   ,25,1000,200   ,135,13);
		move_all(-48.0f,1000,200   ,25,1000,200   ,180,13);
		move_all(-120.0f,1000,200   ,25,1000,200   ,317,13);
		move_all(3.0f,1000,200   ,130-70,1000,200   ,317,13);
		set_zhuashou_kai();
	}
}

// 从绿色工位抓取，抬离工位后转至公共放置姿态，最后松开夹爪。
void na_green(void)
{	
	move_all(-10.0f,1000,200   ,130,1000,200   ,278,13);
	move_all(-50.0f,1000,200   ,130,1000,200   ,278,13);
	set_zhuashou_he();
	move_all(-50.0f,1000,200   ,50,1000,220   ,278,13);
	move_all(-48.0f,1000,200   ,25,1000,220   ,135,13);
	move_all(-48.0f,1000,200   ,33,1000,220   ,135,13);
	set_zhuashou_kai();
}

// 从蓝色工位抓取，再转至公共放置姿态并松开夹爪。
void na_blue(void)
{
	move_all(3.0f,1000,200   ,110,1000,200   ,317,13);
	move_all(3.0f,1000,200   ,130,1000,200   ,317,13);
	set_zhuashou_he();
	move_all(8.0f,1000,200   ,25,1000,220   ,317,13);
	move_all(-48.0f,1000,200   ,25,1000,220   ,135,13);
	move_all(-48.0f,1000,200   ,33,1000,220   ,135,13);
	set_zhuashou_kai();
}

// 从红色工位抓取，再转至公共放置姿态并松开夹爪。
void na_red(void)
{
	move_all(3.0f,1000,200   ,130,1000,200   ,236,13);
	set_zhuashou_he();
	move_all(-50.0f,1000,200   ,50,1000,220   ,236,13);
	move_all(-48.0f,1000,200   ,25,1000,220   ,135,13);
	move_all(-48.0f,1000,200   ,33,1000,220   ,135,13);
	set_zhuashou_kai();
}

// 保留旧取料路径编号；新状态机通过GCS_FIELD_PATH_1/2/3映射调用。
void na(uint8_t task)
{
	if(task == 0x01){
		na_blue();
	}else if(task == 0x02){
		na_green();
	}else if(task == 0x03){
		na_red();
	}
}

// 圆台三组位置的完整抓取路径；编号 1/2/3 对应不同的平推、升降及云台标定姿态。
void yuantai_na(uint8_t task)
{
	if(task == 0x01){
		set_zhuashou_kai();  
		move_all(-100.0f,1000,220   ,50,2000,220   ,278,13);
		set_zhuashou_he();  
		move_all(-48.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,33,2000,220   ,135,13);
		set_zhuashou_kai();	 
	}else if(task == 0x02){
		set_zhuashou_kai();	
		move_all(63.0f,1000,200   ,48,2000,220   ,295,13);
		set_zhuashou_he();   
		move_all(20.0f,1000,200   ,25,2000,220   ,295,13);// 先回缩平推轴至 20，升降轴到 25，云台保持 295 度，再转向公共放置位置。
		move_all(-20.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,33,2000,220   ,135,13);
		set_zhuashou_kai();  
	}else if(task == 0x03){
		set_zhuashou_kai();  
		move_all(63.0f,1000,200   ,48,2000,220   ,261,13);
		set_zhuashou_he();  
		move_all(-48.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,33,2000,220   ,135,13);
		set_zhuashou_kai();  
	}
}

// 圆台两阶段抓取的准备段：仅张爪和预定位，是否开始抓取由调用方决定。
void yuantai_na1(uint8_t task)
{
	if(task == 0x01){
		set_zhuashou_kai();
		move_all(40.0f,1000,200   ,0,2000,200   ,278,13);
	}else if(task == 0x02){
		set_zhuashou_kai();	
		move_all(63.0f,1000,200   ,18,2000,220   ,295,13);
	}else if(task == 0x03){
		set_zhuashou_kai();  
		move_all(63.0f,1000,200   ,18,2000,220   ,261,13);
	}
}

// 圆台两阶段抓取的执行段：本函数不先张爪，应在调用前完成准备。
void yuantai_na2(uint8_t task)
{
	if(task == 0x01){
		move_all(-100.0f,1000,220   ,50,2000,220   ,278,13);
		set_zhuashou_he();   
		move_all(-48.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,33,2000,220   ,135,13);
		set_zhuashou_kai();	 
	}else if(task == 0x02){
		move_all(63.0f,1000,200   ,48,2000,220   ,295,13);
		set_zhuashou_he();   
		move_all(20.0f,1000,200   ,25,2000,220   ,295,13);// 先回缩平推轴至 20，升降轴到 25，云台保持 295 度，再转向公共放置位置。
		move_all(-20.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,33,2000,220   ,135,13);
		set_zhuashou_kai();  
	}else if(task == 0x03){
		move_all(63.0f,1000,200   ,48,2000,220   ,261,13);
		set_zhuashou_he();  
		move_all(-48.0f,1000,200   ,25,2000,220   ,135,13);
		move_all(-48.0f,1000,200   ,33,2000,220   ,135,13);
		set_zhuashou_kai();
	}
}


// 将接收包中的物块像素坐标转换为 direct_x / direct_y；本函数只计算偏移，不驱动底盘。
// task_choose：0x01 使用参考中心 (322, 165)，0x02 使用参考中心 (314, 238)。
// distance：参与像素到实际距离换算的标定距离参数；模式 1 在公式中额外加 80。
// color：目标编号 1/2/3，用于相邻工位间距补偿；为 0 时不执行该编号补偿。
void transfer_position_wukuai(uint8_t task_choose,float distance,uint8_t color)
{
	// 载荷第 1~4 字节为 X、第 5~8 字节为 Y，均按四位十进制 ASCII 解析。
	// 本函数假定数据包已有效接收，不检查字节是否为数字或坐标是否越界。
	x_origin = (Serial_RxPacket[0]-0x30)*1000+(Serial_RxPacket[1]-0x30)*100+(Serial_RxPacket[2]-0x30)*10+(Serial_RxPacket[3]-0x30);
	y_origin = (Serial_RxPacket[4]-0x30)*1000+(Serial_RxPacket[5]-0x30)*100+(Serial_RxPacket[6]-0x30)*10+(Serial_RxPacket[7]-0x30);
	float bilichi = 0;
	if(task_choose == 0x01){
		// 第一组经验标定：以 distance + 80 计算比例，像素中心取 (322, 165)。
		bilichi = -0.0035f*(distance+80.0f) + 1.1967f;
		x_origin = x_origin - 322;
		y_origin = y_origin - 165;
	}else if(task_choose == 0x02){
		// 第二组经验标定：直接用 distance 计算比例，像素中心取 (314, 238)。
		bilichi = -0.0033f*(distance) + 1.1655f;
		x_origin = x_origin - 314;
		y_origin = y_origin - 238;
	}
	direct_x = x_origin * bilichi;   
	direct_y = y_origin * bilichi;
	// 根据目标编号与接收包第 9 字节的识别编号，沿 X 方向补偿一倍或两倍工位间距。
	if(color == 2){
		if(Serial_RxPacket[8] == 0x32){
		}else if(Serial_RxPacket[8] == 0x31){
				direct_x = direct_x + distance_wukuai;
		}else if(Serial_RxPacket[8] == 0x33){
				direct_x = direct_x - distance_wukuai;
		}
	}else if(color == 1){
		if(Serial_RxPacket[8] == 0x31){
		}else if(Serial_RxPacket[8] == 0x32){
			direct_x = direct_x - distance_wukuai;
		}else if(Serial_RxPacket[8] == 0x33){
				direct_x = direct_x - 2*distance_wukuai;
		}
	}else if(color == 3){
		if(Serial_RxPacket[8] == 0x33){
		}else if(Serial_RxPacket[8] == 0x32){
			direct_x = direct_x + distance_wukuai;
		}else if(Serial_RxPacket[8] == 0x31){
				direct_x = direct_x + 2*distance_wukuai;
		}
	}
	// 接收编号为字符 4 时，覆盖上面的结果，采用固定偏移 X=-5、Y=5。
	// 字符 4 的具体业务含义未在此工程中定义，不能据此认定目标已对准。
	if(Serial_RxPacket[8] == 0x34){
		direct_y = 5;direct_x = -5;
	}
}


// 色环像素坐标换算：读取坐标、减去标定中心、乘比例系数，再按目标工位补偿 X 偏移。
// fenbian_choose：选择两组像素坐标标定参数，除此之外的取值不在本函数中处理。
	// fenbian_choose == 0x01：低分辨率标定，参考中心 (316, 238)，换算系数 1.1805555。
	// fenbian_choose == 0x02：高分辨率标定，按接收编号选择参考中心，换算系数 0.29239766。
// task_num：期望对准的工位编号 1/2/3。
	// task_num 为 0 时跳过工位间距补偿；接收标记为字符 4 时仍会使用末尾的固定偏移。
void transfer_position_sehuan(uint8_t fenbian_choose,uint8_t task_num)
{
	// 与物块换算函数一致，前八个载荷字节分别编码四位十进制 ASCII 坐标。
	x_origin = (Serial_RxPacket[0]-0x30)*1000+(Serial_RxPacket[1]-0x30)*100+(Serial_RxPacket[2]-0x30)*10+(Serial_RxPacket[3]-0x30);
	y_origin = (Serial_RxPacket[4]-0x30)*1000+(Serial_RxPacket[5]-0x30)*100+(Serial_RxPacket[6]-0x30)*10+(Serial_RxPacket[7]-0x30);
	float x_center,y_center;// 所选标定的像素参考中心；相减得到的正负号仍沿用接收坐标轴方向。
	if(fenbian_choose == 0x01){
		x_center =316;y_center =238;
		x_origin = x_origin - x_center;
		y_origin = y_origin - y_center;
		
		direct_x = x_origin * 1.1805555;    // 低分辨率标定的像素偏移到实际距离的比例系数；Y 方向使用同一系数。
		direct_y = y_origin * 1.1805555;
	}else if(fenbian_choose == 0x02){
		// 此处按原宏名将接收字符 1/2/3 对应 red/green/blue 的标定中心。
		// 这与 fangzhi / na 的颜色映射不一致；实际颜色关系需结合上位机协议核对。
		if(Serial_RxPacket[8] == 0x31){
			x_center = x_center_red;y_center = y_center_red;
		}else if(Serial_RxPacket[8] == 0x32){
			x_center = x_center_green;y_center = y_center_green;
		}else if(Serial_RxPacket[8] == 0x33){
			x_center = x_center_blue;y_center = y_center_blue;
		}
		x_origin = x_origin - x_center;
		y_origin = y_origin - y_center;
	
		direct_x = x_origin * 0.29239766;    // 高分辨率标定的像素偏移到实际距离的比例系数；Y 方向使用同一系数。
		direct_y = y_origin * 0.29239766;
	}
	
	// 通过接收编号与目标编号的差异，补偿一倍或两倍 distance_wukuai 的横向间距。
	if(task_num == 2){
		if(Serial_RxPacket[8] == 0x32){
		}else if(Serial_RxPacket[8] == 0x31){
				direct_x = direct_x + distance_wukuai;
		}else if(Serial_RxPacket[8] == 0x33){
				direct_x = direct_x - distance_wukuai;
		}
	}else if(task_num == 1){
		if(Serial_RxPacket[8] == 0x31){
		}else if(Serial_RxPacket[8] == 0x32){
			direct_x = direct_x - distance_wukuai;
		}else if(Serial_RxPacket[8] == 0x33){
				direct_x = direct_x - 2*distance_wukuai;
		}
	}else if(task_num == 3){
		if(Serial_RxPacket[8] == 0x33){
		}else if(Serial_RxPacket[8] == 0x32){
			direct_x = direct_x + distance_wukuai;
		}else if(Serial_RxPacket[8] == 0x31){
				direct_x = direct_x + 2*distance_wukuai;
		}
	}
	// 接收标记为字符 4 时采用固定偏移 X=-3、Y=3；本工程未说明该标记的业务含义。
	if(Serial_RxPacket[8] == 0x34){
				direct_y = 3;direct_x = -3;
	}
}

// 等待 PC9 限位输入变低后，设置机械臂/平台姿态并停留；不是完整的各轴回零流程。
void jixie_reset(void)
{
	// 限位未触发时闪烁 LED2，每次间隔约 50 ms；该等待没有超时退出。
	while(swith_out() == 1){
		LED_Toggle2();
		delay_ms1(50);
	}
	
	set_zhuashou_kai();
	move_all(0.0f,1000,200   ,0,1000,200   ,68.4,13);
	set_wukuaipingtai_Angle(20.0f,300);
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	TIM_Cmd(TIM5, ENABLE); 
	// 打开 IMU 接收和 OLED 刷新后永久停留，函数不会返回。
	while(1){}
}

/*
	清除旧接收标志，向树莓派发送一个命令字节，然后阻塞到收到下一个完整数据包。
	兼容旧接口，新增超时；新流程使用带请求编号的动态帧。
*/
void wait_send_shumeipai(uint8_t message,uint16_t time)
{
    uint32_t started=GcsClock_Millis();
    while(Serial_GetRxFlag()) {}
    Serial_SendByte(message);
    while((uint32_t)(GcsClock_Millis()-started)<(time ? time : GCS_REPLY_TIMEOUT_MS)) {
        if(Serial_GetRxFlag()) return;
    }
    Serial_RxLength=0; /* 旧接口等待超时；新状态机不使用此函数。 */
}

// TIM5 更新中断：扫描 IMU 数据，并在 OLED 两行分别显示 fAngle[2] 与 angle。
void TIM5_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM5, TIM_IT_Update) == SET)
	{
		imu_scan(fAcc, fGyro, fAngle);
		TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
		OLED_ShowSignedNum(1,1,fAngle[2],3);
		OLED_ShowChar(1,5,'.');
		OLED_ShowNum(1,6,ABS((fAngle[2]-(int)fAngle[2])*1000),3);
		OLED_ShowSignedNum(2,1,angle,3);
		OLED_ShowChar(2,5,'.');
		OLED_ShowNum(2,6,ABS((angle-(int)angle)*1000),3);
		
	}
}

// 仅清空串口屏 t0 文本控件，不清除整个屏幕，也不清空串口接收缓冲区。
void clear_ckp(void)
{
	sprintf(tjcstr, "t0.txt=\"  \"");
			HMISends(tjcstr);
	        HMISendb(0xff);// HMISendb 内部连发三次，发送串口屏命令结束标记 0xFF 0xFF 0xFF。
}
