﻿#ifndef GCS_TASK_H
#define GCS_TASK_H
#include <stdint.h>
/* 与Python一致：红1、黄2、蓝3、绿4、黑5、浅蓝6。 */
typedef enum { GCS_RED=1, GCS_YELLOW, GCS_BLUE, GCS_GREEN, GCS_BLACK, GCS_LIGHT_BLUE } GcsColor;
typedef struct {
    uint8_t colors[2][3];
    uint8_t rough_by_color[7], storage_by_color[7];
    char code[16];
} GcsTask;
int GcsTask_Parse(const char *code, GcsTask *out);
#endif
