﻿#include "stm32f4xx.h"
#include "gcs_port.h"
#include "PWM.h"
#include "yyb_move.h"
#include "delay.h"
#include "pid.h"
#include <math.h>

void yuantai_na(uint8_t path);
void na(uint8_t path);
void fangzhi(uint8_t path);
void fangzhi_maduo(uint8_t path);

/* TODO：此处接回你的跑图，不增加、不猜测任何行驶距离。
   m->route区分二维码区/原料区/粗加工区/暂存区/终点；m->batch区分批次。
   原压缩包main没有完整跑图，不能凭空恢复。 */
GcsResult GcsUser_Route(const GcsMachine *m,uint8_t first)
{
    (void)m; (void)first;
    return GCS_BUSY;
}
/* TODO：接入已验证的观察/避让姿态；完成后返回OK。
   m->stage、m->position、m->batch决定观察哪一区域/高度。
   若相机固定且当前姿态已经正确，也必须由你验证后返回OK。 */
GcsResult GcsUser_Observe(const GcsMachine *m,uint8_t first)
{
    (void)m; (void)first;
    return GCS_BUSY;
}
/* TODO：从车载平台取出物料并保持夹持，准备交给原fangzhi动作。
   原na是“场地取回并放到车上”，不能拿它反向代替本动作。 */
GcsResult GcsUser_CarrierPickup(const GcsMachine *m,uint8_t first)
{
    (void)m; (void)first;
    return GCS_BUSY;
}
static uint8_t path_for(uint8_t pos)
{
    static const uint8_t paths[4]={0,GCS_FIELD_PATH_1,GCS_FIELD_PATH_2,GCS_FIELD_PATH_3};
    return pos<=3u ? paths[pos] : 0u;
}
GcsResult GcsPort_Action(GcsAction action,const GcsMachine *m,uint8_t first)
{
    uint8_t path;
    if(m->dry_run) return GCS_OK; /* 逻辑演练不调用任何原运动函数。 */
    if(!GCS_MECHANISM_READY) return GCS_FAILED;
    switch(action) {
    case GCS_ACT_ROUTE: return GcsUser_Route(m,first);
    case GCS_ACT_OBSERVE: return GcsUser_Observe(m,first);
    case GCS_ACT_CORRECT:
        /* 换算矩阵已含方向。不再做旧颜色/150mm工位间距补偿。
           避免原底盘函数在零位移下计算x/ABS(x)。 */
        if(fabsf(m->move_x)>=1.0f) car_move2(m->move_x,0,150,100);
        if(fabsf(m->move_y)>=1.0f) car_move1(0,m->move_y,150,100);
        delay_ms1(150);
        return GCS_OK;
    case GCS_ACT_RAW_PICK:
        if(m->pick_path<1u || m->pick_path>3u) return GCS_FAILED;
        set_wukuaipingtai_weizhi(m->slot);
        delay_ms1(GCS_PLATFORM_SETTLE_MS);
        yuantai_na(m->pick_path); /* 原抓取+回车载平台松爪，函数体不变。 */
        return GCS_OK;
    case GCS_ACT_FIELD_PICK:
        path=path_for(m->position);
        if(!path) return GCS_FAILED;
        set_wukuaipingtai_weizhi(m->slot);
        delay_ms1(GCS_PLATFORM_SETTLE_MS);
        na(path); /* 原工位取回路径不变。 */
        return GCS_OK;
    case GCS_ACT_CARRIER_OUT:
        if(first) {
            set_wukuaipingtai_weizhi(m->slot);
            delay_ms1(GCS_PLATFORM_SETTLE_MS);
        }
        return GcsUser_CarrierPickup(m,first);
    case GCS_ACT_PUT: case GCS_ACT_STACK:
        path=path_for(m->position);
        if(!path) return GCS_FAILED;
        if(action==GCS_ACT_STACK) fangzhi_maduo(path);
        else fangzhi(path);
        return GCS_OK;
    default: return GCS_FAILED;
    }
}
void GcsPort_Stop(void)
{
#if !GCS_DRY_RUN
    /* 只能停止后续调度和底盘。原机械臂阻塞动作不会被此函数异步中止。 */
    TIM_Cmd(TIM4,DISABLE);
    dianji_move_flag=0;
    car_move(0,0,0);
#endif
}
