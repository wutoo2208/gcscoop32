﻿#include "gcs_task.h"
#include <string.h>
int GcsTask_Parse(const char *code, GcsTask *out)
{
    GcsTask t;
    uint8_t seen1=0, seen2=0, rough=0, storage=0;
    uint8_t c, c2, p, s;
    int i;
    if (!code || !out || strlen(code) != 15u ||
        code[3]!='+' || code[7]!='+' || code[11]!='+') return 0;
    memset(&t, 0, sizeof(t));
    for (i=0; i<3; i++) {
        if (code[i]<'1' || code[i]>'6' || code[8+i]<'1' || code[8+i]>'6' ||
            code[4+i]<'1' || code[4+i]>'3' || code[12+i]<'1' || code[12+i]>'3') return 0;
        c=(uint8_t)(code[i]-'0'); c2=(uint8_t)(code[8+i]-'0');
        p=(uint8_t)(code[4+i]-'0'); s=(uint8_t)(code[12+i]-'0');
        if ((seen1 & (1u<<c)) || (seen2 & (1u<<c2)) ||
            (rough & (1u<<p)) || (storage & (1u<<s))) return 0;
        seen1 |= (uint8_t)(1u<<c); seen2 |= (uint8_t)(1u<<c2);
        rough |= (uint8_t)(1u<<p); storage |= (uint8_t)(1u<<s);
        t.colors[0][i]=c; t.colors[1][i]=c2;
        /* 新增：两张表都以第一组颜色为键，两批共用对应关系。 */
        t.rough_by_color[c]=p; t.storage_by_color[c]=s;
    }
    if (seen1 != seen2) return 0;
    memcpy(t.code, code, 16u);
    *out=t;
    return 1;
}
