﻿#include "gcs_frame.h"
#include <string.h>

void GcsFrame_Init(GcsReceiver *r) { memset(r, 0, sizeof(*r)); }

/* 新增：FF开始、FE结束，FIFO保留连续帧；不在中断中解析任务/执行动作。 */
void GcsFrame_Byte(GcsReceiver *r, uint8_t byte, uint32_t now)
{
    uint8_t next;
    if (r->receiving && (uint32_t)(now - r->last_byte_ms) > GCS_RX_GAP_MS) {
        r->receiving = 0; r->used = 0; r->malformed++;
    }
    r->last_byte_ms = now;
    if (byte == 0xFFu) {
        r->receiving = 1; r->used = 0; return;
    }
    if (!r->receiving) return;
    if (byte == 0xFEu) {
        r->receiving = 0;
        if (r->used == 0) { r->malformed++; return; }
        next = (uint8_t)((r->head + 1u) % GCS_FRAME_QUEUE);
        if (next == r->tail) { r->dropped++; return; }
        memcpy(r->queue[r->head].text, r->assembling, r->used);
        r->queue[r->head].text[r->used] = '\0';
        r->queue[r->head].length = r->used;
        r->head = next;
        return;
    }
    if (byte < 0x20u || byte > 0x7Eu || r->used >= GCS_FRAME_MAX) {
        r->receiving = 0; r->used = 0; r->malformed++; return;
    }
    r->assembling[r->used++] = (char)byte;
}
int GcsFrame_Pop(GcsReceiver *r, GcsFrame *out)
{
    if (r->tail == r->head) return 0;
    *out = r->queue[r->tail];
    r->tail = (uint8_t)((r->tail + 1u) % GCS_FRAME_QUEUE);
    return 1;
}
