﻿#ifndef GCS_PORT_H
#define GCS_PORT_H
#include "gcs_fsm.h"
GcsResult GcsPort_Action(GcsAction action,const GcsMachine *m,uint8_t first);
void GcsPort_Stop(void);
/* 以下三个接口由你接入原有跑图/机构流程；BUSY等待、OK完成、FAILED失败。
   first只在本次动作第一次调用为1，避免重复启动电机。 */
GcsResult GcsUser_Route(const GcsMachine *m,uint8_t first);
GcsResult GcsUser_Observe(const GcsMachine *m,uint8_t first);
GcsResult GcsUser_CarrierPickup(const GcsMachine *m,uint8_t first);
#endif
