﻿#ifndef GCS_CLOCK_H
#define GCS_CLOCK_H
#include <stdint.h>
void GcsClock_Init(void);
uint32_t GcsClock_Millis(void);
#endif
