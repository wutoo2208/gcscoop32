﻿#include "stm32f4xx.h"
#include "gcs_clock.h"
static volatile uint32_t gcs_ms;
/* 新增独立TIM7时基；不占用原SysTick延时和TIM2/4/5/6。 */
void GcsClock_Init(void)
{
    RCC_ClocksTypeDef clocks;
    TIM_TimeBaseInitTypeDef timer;
    NVIC_InitTypeDef nvic;
    uint32_t hz;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7,ENABLE);
    RCC_GetClocksFreq(&clocks);
    hz=clocks.PCLK1_Frequency;
    if(clocks.PCLK1_Frequency != clocks.HCLK_Frequency) hz*=2u;
    TIM_TimeBaseStructInit(&timer);
    timer.TIM_Prescaler=(uint16_t)(hz/1000000u-1u);
    timer.TIM_Period=1000u-1u;
    TIM_TimeBaseInit(TIM7,&timer);
    TIM_ClearITPendingBit(TIM7,TIM_IT_Update);
    TIM_ITConfig(TIM7,TIM_IT_Update,ENABLE);
    nvic.NVIC_IRQChannel=TIM7_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority=2;
    nvic.NVIC_IRQChannelSubPriority=0;
    nvic.NVIC_IRQChannelCmd=ENABLE;
    NVIC_Init(&nvic);
    TIM_Cmd(TIM7,ENABLE);
}
uint32_t GcsClock_Millis(void) { return gcs_ms; }
void TIM7_IRQHandler(void)
{
    if(TIM_GetITStatus(TIM7,TIM_IT_Update)!=RESET) {
        TIM_ClearITPendingBit(TIM7,TIM_IT_Update);
        gcs_ms++;
    }
}
