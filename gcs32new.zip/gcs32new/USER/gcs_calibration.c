﻿#include "gcs_config.h"
/* TODO：按实际场地填写。每行依次是编号0(不用)、1、2、3。
   行0=原料抓取路径，行1=粗加工放置，行2=粗加工取回，行3=暂存放置。
   第二批暂存针对下层物料顶面定位，与第一批地面圆环可能有视差；
   第二批使用下方gcs_stack_calibration独立标定。
   默认ready=0、矩阵=0；320/240仅供640x480逻辑演练，不是实测中心。 */
#define UNCAL {0u,320.0f,240.0f,0.0f,0.0f,0.0f,0.0f}
const GcsCalibration gcs_calibration[4][4] = {
    { UNCAL, UNCAL, UNCAL, UNCAL },
    { UNCAL, UNCAL, UNCAL, UNCAL },
    { UNCAL, UNCAL, UNCAL, UNCAL },
    { UNCAL, UNCAL, UNCAL, UNCAL }
};

/* 第二批暂存：下层同色物料顶面的对准参考，独立于空圆环。 */
const GcsCalibration gcs_stack_calibration[4]={ UNCAL, UNCAL, UNCAL, UNCAL };
