﻿#ifndef GCS_FSM_H
#define GCS_FSM_H
#include "gcs_task.h"
#include "gcs_config.h"
typedef enum { GCS_RAW=0, GCS_ROUGH_PUT, GCS_ROUGH_GET, GCS_STORAGE_PUT } GcsStage;
typedef enum { GCS_IDLE=0, GCS_ROUTE, GCS_Q_SEND, GCS_Q_WAIT, GCS_PREPARE,
    GCS_V_SEND, GCS_V_WAIT, GCS_CORRECT, GCS_TAKE_OUT, GCS_EXECUTE,
    GCS_PROCESS_WAIT, GCS_DONE, GCS_FAULT } GcsState;
typedef enum { GCS_TO_QR=0, GCS_TO_RAW, GCS_TO_ROUGH, GCS_TO_STORAGE, GCS_TO_FINISH } GcsRoute;
typedef enum { GCS_ACT_ROUTE=1, GCS_ACT_OBSERVE, GCS_ACT_CORRECT, GCS_ACT_RAW_PICK,
    GCS_ACT_FIELD_PICK, GCS_ACT_CARRIER_OUT, GCS_ACT_PUT, GCS_ACT_STACK } GcsAction;
typedef enum { GCS_BUSY=0, GCS_OK=1, GCS_FAILED=2 } GcsResult;
typedef struct GcsMachine GcsMachine;
typedef struct {
    void (*send)(const char *text);
    GcsResult (*action)(GcsAction action, const GcsMachine *m, uint8_t first);
    void (*stop)(void);
} GcsOps;
struct GcsMachine {
    GcsTask task;
    GcsOps ops;
    GcsState state;
    GcsStage stage;
    GcsRoute route;
    uint8_t batch, index, color, position, slot, pick_path;
    uint8_t slots[4], rough[4], storage[4], layers[4], held_color;
    uint8_t dry_run, aligned, corrections, action_started;
    uint32_t sequence, waiting_sequence, deadline, action_deadline;
    uint16_t x, y;
    float move_x, move_y;
    char expected_kind, error[32];
};
void GcsAlignment_Offset(const GcsCalibration *cal,float ex,float ey,float *dx,float *dy);
void GcsMachine_Init(GcsMachine *m, const GcsOps *ops, uint8_t dry_run);
void GcsMachine_Start(GcsMachine *m);
void GcsMachine_Poll(GcsMachine *m, uint32_t now);
void GcsMachine_Message(GcsMachine *m, const char *text, uint32_t now);
#endif
